package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "explored_places")
data class ExploredPlace(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nameEn: String,
    val nameUr: String,
    val eraEn: String,
    val eraUr: String,
    val historyEn: String,
    val historyUr: String,
    val peakEn: String,
    val peakUr: String,
    val connectionEn: String,
    val connectionUr: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imagePath: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val note: String? = null // Optional personal note on the discovery
)
