package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExploredPlaceDao {
    @Query("SELECT * FROM explored_places ORDER BY timestamp DESC")
    fun getAllExploredPlaces(): Flow<List<ExploredPlace>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExploredPlace(place: ExploredPlace): Long

    @Update
    suspend fun updateExploredPlace(place: ExploredPlace)

    @Delete
    suspend fun deleteExploredPlace(place: ExploredPlace)

    @Query("DELETE FROM explored_places")
    suspend fun clearAllPlaces()
}
