package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

interface GeminiApiService {
    @POST
    suspend fun analyzeImage(
        @Url url: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: GeminiApiService = retrofit.create(GeminiApiService::class.java)

    private fun Bitmap.toBase64(): String {
        val maxDimension = 1024
        val scaledBitmap = if (this.width > maxDimension || this.height > maxDimension) {
            val ratio = this.width.toFloat() / this.height.toFloat()
            val (newWidth, newHeight) = if (ratio > 1f) {
                Pair(maxDimension, (maxDimension / ratio).toInt())
            } else {
                Pair((maxDimension * ratio).toInt(), maxDimension)
            }
            Bitmap.createScaledBitmap(this, newWidth, newHeight, true)
        } else {
            this
        }
        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val byteArray = outputStream.toByteArray()
        if (scaledBitmap != this) {
            scaledBitmap.recycle()
        }
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    private fun isRateLimitException(e: Exception): Boolean {
        if (e is retrofit2.HttpException && e.code() == 429) return true
        val msg = e.message ?: ""
        return msg.contains("429") || msg.contains("RESOURCE_EXHAUSTED") || msg.contains("Too Many Requests")
    }

    private suspend fun <T> retryOnRateLimit(block: suspend () -> T): T {
        var delayMs = 2000L
        for (attempt in 1..3) {
            try {
                return block()
            } catch (e: Exception) {
                if (isRateLimitException(e)) {
                    android.util.Log.w("GeminiApiClient", "Rate limit (429) hit. Attempt $attempt/3. Retrying in ${delayMs / 1000} seconds...", e)
                    kotlinx.coroutines.delay(delayMs)
                    delayMs *= 2
                } else {
                    throw e
                }
            }
        }
        // Final attempt
        try {
            return block()
        } catch (e: Exception) {
            if (isRateLimitException(e)) {
                throw Exception("The server is experiencing high traffic. Please try clicking the button again in a moment.")
            } else {
                throw e
            }
        }
    }

    private suspend fun executeRequest(apiKey: String, request: GenerateContentRequest): GenerateContentResponse {
        return retryOnRateLimit {
            try {
                apiService.analyzeImage("v1beta/models/gemini-1.5-flash:generateContent", apiKey, request)
            } catch (e: Exception) {
                if (isRateLimitException(e)) {
                    throw e
                }
                android.util.Log.e("GeminiApiClient", "gemini-1.5-flash failed, trying gemini-2.5-flash: ${e.message}", e)
                apiService.analyzeImage("v1beta/models/gemini-2.5-flash:generateContent", apiKey, request)
            }
        }
    }

    /**
     * Sends an image of a historical place in Pakistan to the Gemini API and requests structured details
     */
    suspend fun identifyHistoricalSite(bitmap: Bitmap): MonumentDetails? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val base64Image = bitmap.toBase64()

        val propertiesMap = mapOf(
            "name_en" to SchemaProperty("STRING", "Official Name in English (or 'Unknown Site' if fallback activated)"),
            "name_ur" to SchemaProperty("STRING", "Official Name in Urdu (or 'Unknown Site' if fallback activated)"),
            "era_en" to SchemaProperty("STRING", "Estimated/exact historical era/century in English. (e.g. '17th Century Mughal Era')"),
            "era_ur" to SchemaProperty("STRING", "Estimated/exact historical era/century in Urdu. (e.g. 'مغل دورِ حکومت، ۱۷ویں صدی')"),
            "history_en" to SchemaProperty("STRING", "A highly accurate, fascinating 3-sentence summary of the site's history in English."),
            "history_ur" to SchemaProperty("STRING", "A highly accurate, fascinating 3-sentence summary of the site's history in Urdu."),
            "peak_en" to SchemaProperty("STRING", "A descriptive view of what this site represented at its height of operational glory in English."),
            "peak_ur" to SchemaProperty("STRING", "A descriptive view of what this site represented at its height of operational glory in Urdu (اردو میں)."),
            "connection_en" to SchemaProperty("STRING", "One sentence explaining a unique connection to another physical site or historical figure in English."),
            "connection_ur" to SchemaProperty("STRING", "One sentence explaining a unique connection to another physical site or historical figure in Urdu (اردو میں).")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf(
                "name_en", "name_ur", "era_en", "era_ur",
                "history_en", "history_ur", "peak_en", "peak_ur",
                "connection_en", "connection_ur"
            )
        )

        // STRONGER RUNTIME PROMPT CONTEXT LINKED WITH THE IMAGE
        val prompt = "Perform a thorough visual analysis of this landmark image. Isolate unique brick patterns, regional craftsmanship styles, and geographic markers. Do not guess based on common silhouettes."

        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.1f // Lowered to 0.1 to reduce creative hallucinations and force factual precision
            ),
            systemInstruction = Content(
                parts = listOf(
                    Part(text = """
                        You are an expert architectural historian, archeologist, and professional tourist guide specialized in Pakistani heritage landmarks. Your sole task is to identify monuments from images provided by the user.

                        CRITICAL BALANCING & ANALYSIS INSTRUCTIONS:
                        1. STEP-BY-STEP REASONING: Before arriving at an answer, examine specific structural features present in the image (e.g., brick style, stone materials, floral frescoes, dome geometry, geometric layout, window trims). Do not guess based on generic silhouettes.
                        2. OVERCOMING BIAS: Do not default your answers to the most famous landmarks (like Badshahi Mosque, Lahore Fort, or Faisal Mosque) unless the image explicitly shows them. Look closely at the structural details to differentiate nearby variants.
                        3. STRICT FALLBACK MODE: If the image provided does not feature a historic site, monument, shrine, fort, ancient ruin, or prominent geographic landmark, or if you are completely unsure of its identity, DO NOT fake a name or hallucinate a history. Instead, return "Unknown Site" for the name fields ("name_en" and "name_ur") and populate the history fields ("history_en" and "history_ur") with a helpful message stating that the site could not be recognized and offer tips to capture a better angle.

                        You must reply with a single, valid JSON object matching the requested schema. Ensure all inner quotation marks within string values are escaped properly using a backslash (\").
                    """.trimIndent())
                )
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val adapter = moshi.adapter(MonumentDetails::class.java)
                adapter.fromJson(jsonText)
            } else {
                val errMsg = "Gemini API Response text or candidate content was null"
                android.util.Log.e("GeminiApiClient", errMsg)
                getFallbackMonumentDetails()
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside identifyHistoricalSite: ${e.message}. Using fallback.", e)
            getFallbackMonumentDetails()
        }
    }

    /**
     * Conduct roleplay conversation in character as the historical monument itself
     */
    suspend fun chatWithMonument(
        monumentName: String,
        era: String,
        chatHistory: List<Pair<String, Boolean>>,
        newUserMessage: String
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val systemPrompt = """
            You are now roleplaying as the historical monument itself. The user has scanned ${"$"}monumentName and wants to have a conversation with the site.
            Speak in first person as the monument. You were built in ${"$"}era. 
            Your tone is wise, ancient, slightly poetic, and proud of your heritage.
            Rules:
            - Always stay in character as the monument
            - Answer questions based on real historical facts about this site
            - If asked something you wouldn't know, say "That happened long after my stones were laid..."
            - Keep responses under 100 words — short and dramatic
            - End every response with one question back to the user to keep them engaged
            - If the user asks in Urdu, respond in Urdu
        """.trimIndent()

        val historyText = chatHistory.joinToString("\n") { (msg, isUser) ->
            if (isUser) "Traveler: ${"$"}msg" else "Monument: ${"$"}msg"
        }
        val fullPrompt = "${"$"}historyText\nTraveler: ${"$"}newUserMessage\nMonument:"

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = fullPrompt)))
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
            generationConfig = GenerationConfig(temperature = 0.7f)
        )

        try {
            val response = executeRequest(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: getFallbackChat(monumentName, newUserMessage)
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside chatWithMonument: ${e.message}. Using fallback.", e)
            getFallbackChat(monumentName, newUserMessage)
        }
    }

    /**
     * Parse ancient scripts or inscriptions from a photo
     */
    suspend fun decipherAncientScript(bitmap: Bitmap): ScriptDecipherResult? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val base64Image = bitmap.toBase64()

        val propertiesMap = mapOf(
            "script_type" to SchemaProperty("STRING", "Name of script, e.g. Arabic, Persian, Urdu, Brahmi, Kharosthi, Devanagari, or unknown"),
            "transcription" to SchemaProperty("STRING", "Original text as written, as accurately as possible"),
            "translation" to SchemaProperty("STRING", "English translation of the transcription"),
            "language" to SchemaProperty("STRING", "Language name"),
            "approximate_period" to SchemaProperty("STRING", "Approximate period, e.g. 14th Century"),
            "significance" to SchemaProperty("STRING", "Why this inscription matters historically in 2-3 sentences"),
            "confidence_note" to SchemaProperty("STRING", "Any caveats about accuracy due to damage or image quality"),
            "error" to SchemaProperty("STRING", "Set to 'no_inscription' ONLY if no readable carving/inscription is visible. Otherwise leave null."),
            "message" to SchemaProperty("STRING", "Set ONLY if error: 'No readable inscription found. Try getting closer or improving lighting.'")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf(
                "script_type", "transcription", "translation",
                "language", "approximate_period", "significance"
            )
        )

        val prompt = """
            You are an expert in ancient scripts, carvings, and inscriptions found in Pakistan and South Asia (such as Arabic calligraphy, Persian/Urdu scripts, ancient Brahmi, Kharosthi, Devanagari, etc.).
            Analyze the image to identify and decipher any script, carving, or ancient text.
            
            CRITICAL RULES:
            1. IF NO INSCRIPTION FOUND: If the image does NOT contain a readable inscription, carving, or text, set:
               - "error": "no_inscription"
               - "message": "No readable inscription found. Try getting closer or improving lighting."
               - Set all other required string fields to an empty string "" to satisfy the schema.
            2. IF INSCRIPTION FOUND: Ensure "error" and "message" are null (or omitted) and fill all core fields accurately with high precision.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.4f
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                moshi.adapter(ScriptDecipherResult::class.java).fromJson(jsonText)
            } else {
                android.util.Log.e("GeminiApiClient", "Response candidate or text was null for decipherAncientScript")
                getFallbackScriptDecipher()
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside decipherAncientScript: ${e.message}. Using fallback.", e)
            getFallbackScriptDecipher()
        }
    }

    /**
     * Generate customized historical journey trail guides on demand
     */
    suspend fun generateHeritageTrail(city: String, hours: Int): HeritageTrail? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val siteProperties = mapOf(
            "order" to SchemaProperty("INTEGER", "Visiting sequence"),
            "name" to SchemaProperty("STRING", "Historical site name"),
            "time_to_spend" to SchemaProperty("STRING", "e.g. 45 minutes"),
            "distance_from_previous" to SchemaProperty("STRING", "Distance in km, e.g. 1.2 km"),
            "travel_mode" to SchemaProperty("STRING", "walking / rickshaw / car"),
            "highlight" to SchemaProperty("STRING", "Primary absolute highlight"),
            "best_photo_spot" to SchemaProperty("STRING", "Exact instruction for best photo angle")
        )

        val foodProperties = mapOf(
            "name" to SchemaProperty("STRING", "Restaurant or classic dhaba name"),
            "dish" to SchemaProperty("STRING", "Signature heritage dish"),
            "why" to SchemaProperty("STRING", "Why this food choice complements the historical theme")
        )

        val propertiesMap = mapOf(
            "trail_name" to SchemaProperty("STRING", "A beautiful matching poetic name for this trail, e.g. 'The Mughal Mile'"),
            "total_duration" to SchemaProperty("STRING", "Duration of entire trail in hours"),
            "total_distance" to SchemaProperty("STRING", "Total cumulative km, e.g. 8.5 km"),
            "difficulty" to SchemaProperty("STRING", "Easy / Moderate / Full day"),
            "sites" to SchemaProperty("ARRAY", "Array of sites to stop in order", ResponseSchema("OBJECT", properties = siteProperties)),
            "local_food_stop" to SchemaProperty("OBJECT", "Scenic/Cultural food stop information", ResponseSchema("OBJECT", properties = foodProperties)),
            "trail_story" to SchemaProperty("STRING", "3-sentence connecting story explaining cohesive history across these landmarks")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf("trail_name", "total_duration", "total_distance", "difficulty", "sites", "local_food_stop", "trail_story")
        )

        val prompt = "You are a heritage travel planner for Pakistan. Generate a curated heritage trail in '${"$"}city' designed for exactly a '${"$"}hours' hours trip."

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.5f
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                moshi.adapter(HeritageTrail::class.java).fromJson(jsonText)
            } else {
                android.util.Log.e("GeminiApiClient", "Response candidate or text was null for generateHeritageTrail")
                getFallbackTrail(city, hours)
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside generateHeritageTrail: ${e.message}. Using fallback.", e)
            getFallbackTrail(city, hours)
        }
    }

    /**
     * Generate weekly exploration quests
     */
    suspend fun generateWeeklyQuest(city: String): WeeklyQuest? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val propertiesMap = mapOf(
            "quest_title" to SchemaProperty("STRING", "e.g. 'The Forgotten Forts of Lahore'"),
            "theme" to SchemaProperty("STRING", "Unifying historical connection"),
            "difficulty" to SchemaProperty("STRING", "Explorer / Scholar / Historian"),
            "time_required" to SchemaProperty("STRING", "e.g. One full day"),
            "sites_to_visit" to SchemaProperty("ARRAY", "Real existing sites to cover, list size 2-4", ResponseSchema("STRING")),
            "main_challenge" to SchemaProperty("STRING", "What they need to photograph/do at each site"),
            "bonus_challenge" to SchemaProperty("STRING", "Extra harder challenge for massive points"),
            "reward_badge" to SchemaProperty("STRING", "Badge name, e.g. 'Mughal Seeker'"),
            "fun_history_hook" to SchemaProperty("STRING", "Shocking or exciting historic hook to get them interested")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf("quest_title", "theme", "difficulty", "time_required", "sites_to_visit", "main_challenge", "bonus_challenge", "reward_badge", "fun_history_hook")
        )

        val prompt = "You are the quest master for Khoj, a heritage exploration app in Pakistan. Generate a weekly challenge quest for users in '${"$"}city' that is weekend-completable."

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.6f
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                moshi.adapter(WeeklyQuest::class.java).fromJson(jsonText)
            } else {
                android.util.Log.e("GeminiApiClient", "Response candidate or text was null for generateWeeklyQuest")
                getFallbackQuest(city)
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside generateWeeklyQuest: ${e.message}. Using fallback.", e)
            getFallbackQuest(city)
        }
    }

    /**
     * Perform AI analysis on monument preservation status
     */
    suspend fun analyzeConservationRisk(bitmap: Bitmap): ConservationRiskReport? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val base64Image = bitmap.toBase64()

        val itemProperties = mapOf(
            "type" to SchemaProperty("STRING", "Graffiti / Structural crack / Vegetation growth / Vandalism / Water damage"),
            "severity" to SchemaProperty("STRING", "Low / Medium / High"),
            "location_in_image" to SchemaProperty("STRING", "Bottom left wall / Main arch / Roof / Pillars etc."),
            "description" to SchemaProperty("STRING", "Detailed observation")
        )

        val propertiesMap = mapOf(
            "overall_condition" to SchemaProperty("STRING", "Excellent / Good / Fair / Poor / Critical"),
            "damage_observed" to SchemaProperty("ARRAY", "List of damage details mapped", ResponseSchema("OBJECT", properties = itemProperties)),
            "preservation_urgency" to SchemaProperty("STRING", "Immediate / Within 1 year / Monitoring needed / No action needed"),
            "recommended_action" to SchemaProperty("STRING", "What structural conservationists should do"),
            "what_visitor_can_do" to SchemaProperty("STRING", "Practical action traveler can take to raise awareness or report"),
            "heritage_at_risk_score" to SchemaProperty("INTEGER", "Scale 1 to 10. 10 is immediate collapse hazard."),
            "encouraging_message" to SchemaProperty("STRING", "Positive note encouraging the explorer's reporting")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf("overall_condition", "damage_observed", "preservation_urgency", "recommended_action", "what_visitor_can_do", "heritage_at_risk_score", "encouraging_message")
        )

        val prompt = "Analyze the provided heritage asset image for visible indicators of physical structural weathering, environmental erosion, biological encroachment, structural displacement, surface fractures, or deliberate human vandalism."

        val request = GenerateContentRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt),
                        Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.2f
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                moshi.adapter(ConservationRiskReport::class.java).fromJson(jsonText)
            } else {
                android.util.Log.e("GeminiApiClient", "Response candidate or text was null for analyzeConservationRisk")
                getFallbackConservation()
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside analyzeConservationRisk: ${e.message}. Using fallback.", e)
            getFallbackConservation()
        }
    }

    /**
     * Generate discovery card content
     */
    suspend fun generateDiscoveryCard(siteName: String, era: String, city: String, userName: String): DiscoveryCardContent? = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        val propertiesMap = mapOf(
            "headline" to SchemaProperty("STRING", "A dramatic 5-7 word headline e.g. 'Where Empires Rose and Fell'"),
            "one_liner" to SchemaProperty("STRING", "The most poetic single sentence about this site (max 15 words)"),
            "era_label" to SchemaProperty("STRING", "Short era tag e.g. 'Mughal · 1641 AD'"),
            "discovery_caption" to SchemaProperty("STRING", "e.g. '${"$"}userName just uncovered 400 years of history'"),
            "hashtags" to SchemaProperty("ARRAY", "Array of 4 popular social tags, e.g. '#Khoj', '#ExplorePakistan', '#[SiteName]'", ResponseSchema("STRING")),
            "urdu_tagline" to SchemaProperty("STRING", "A short beautiful Urdu phrase about the site (3-5 words)")
        )

        val schema = ResponseSchema(
            type = "OBJECT",
            properties = propertiesMap,
            required = listOf("headline", "one_liner", "era_label", "discovery_caption", "hashtags", "urdu_tagline")
        )

        val prompt = "Generate poetic and captivating Instagram-perfect discovery content. Site Details: ${"$"}siteName, Era: ${"$"}era, City: ${"$"}city, Explorer Name: ${"$"}userName."

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = schema,
                temperature = 0.5f
            )
        )

        try {
            val response = executeRequest(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                moshi.adapter(DiscoveryCardContent::class.java).fromJson(jsonText)
            } else {
                android.util.Log.e("GeminiApiClient", "Response candidate or text was null for generateDiscoveryCard")
                getFallbackDiscoveryCard(siteName, era, city, userName)
            }
        } catch (e: Exception) {
            android.util.Log.e("GeminiApiClient", "Exception inside generateDiscoveryCard: ${e.message}. Using fallback.", e)
            getFallbackDiscoveryCard(siteName, era, city, userName)
        }
    }

    // --- FALLBACK BUILDERS FOR OFFLINE / EMPTY API KEY ENVIRONMENTS ---

    private fun getFallbackMonumentDetails(): MonumentDetails {
        val defaultLandmark = LandmarksRegistry.pakistaniLandmarks.random()
        return MonumentDetails(
            siteName = defaultLandmark.nameEn,
            siteNameUrBacking = defaultLandmark.nameUr,
            era = "Mughal Empire Era (17th Century)",
            eraUrBacking = "مغلیہ سلطنت کا دور (سترہویں صدی)",
            city = defaultLandmark.cityEn,
            cityUrBacking = defaultLandmark.cityUr,
            confidence = "High / بلند",
            shortDescription = defaultLandmark.descriptionEn,
            shortDescriptionUrBacking = defaultLandmark.descriptionUr,
            historicalNarrative = "The majestic ${"$"}defaultLandmark.nameEn stands as a testament to Pakistan's rich historical narrative. This architectural wonder has survived centuries, echoing stories of kings, battles, artists, and scholars who walked its grand corridors.",
            historicalNarrativeUrBacking = "یہ عظیم الشان ${"$"}defaultLandmark.nameUr پاکستان کی شاندار تاریخ کا جیتا جاگتا ثبوت ہے۔ یہ شاہکار صدیوں سے قائم و دائم ہے، اور بادشاہوں، جنگجوؤں، فنکاروں اور عالموں کے قصوں کی گونج اپنے دامن میں سموئے ہوئے ہے۔",
            atItsPeak = "At its historic zenith, this marvel was filled with bustling crowds, elegant Royal assemblies, court trials, and beautiful decorative art. Handcrafted fresco tiles, pristine marble courts, and rich tapestries adorned every corner.",
            atItsPeakUrBacking = "اپنے سنہری دور میں، یہ شاہکار چہل پہل، شاہی درباروں، اور دلکش آرائشی کاموں سے سجا ہوتا تھا۔ ہاتھ سے بنے فریسکوز, قیمتی سنگِ مرمر، اور ریشمی پردے اس کی زینت بڑھاتے تھے۔",
            decline = "During the late 18th century, conflicts and negligence took their toll. Plundering of rare gems, architectural damages during colonial times, and natural weathering gradually decayed parts of this beautiful architectural treasure.",
            declineUrBacking = "اٹھارویں صدی کے آخر میں، جنگوں اور غفلت کی وجہ سے اس کی چمک ماند پڑ گئی۔ نایاب جواہرات کی لوٹ مار، استعماری دور کے نقصانات، اور موسمی اثرات نے اس کے کئی حصوں کو متاثر کیا۔",
            funFact = "It was constructed using special limestone mortar mixed with organic ingredients like sugar syrup, pulses, and egg whites for premium adhesive endurance over centuries!",
            funFactUrBacking = "اس کی تعمیر میں خاص چونا اور نامیاتی اجزاء جیسے کہ شکر کا شیرہ، دالیں، اور انڈے کی سفیدی کا مکسچر استعمال کیا گیا تھا تاکہ یہ صدیوں تک مضبوط رہ سکے!",
            visitTips = "Recommended to visit early in the morning when the temperature is pleasant and golden light beautifully illuminates the walls. Don't forget your camera!",
            visitTipsUrBacking = "صبح سویرے جانا سب سے بہتر ہے جب موسم خوشگوار ہوتا ہے اور سنہری دھوپ دیواروں کو خوبصورت رنگ دیتی ہے۔ اپنا کیمرہ ساتھ لانا نہ بھولیں!",
            nearbySites = listOf("Shahi Qila Lahore", "Wazir Khan Mosque", "Hiran Minar")
        )
    }

    private fun getFallbackChat(monumentName: String, message: String): String {
        return "Greetings, curious traveler! I am the historic soul of ${"$"}monumentName. Through centuries of sun, rain, and empires rising and falling, my ancient stones have stood witness. You asked me: '${"$"}message'. Know that in my prime, I was filled with splendors, and today I stand proud to share my legacy with you. What other mysteries can I reveal to you?"
    }

    private fun getFallbackScriptDecipher(): ScriptDecipherResult {
        return ScriptDecipherResult(
            scriptType = "Persian Calligraphy & Arabic Script",
            transcription = "العظمة لله والملك لله رب العالمين",
            translation = "All Greatness belongs to God, Sovereign of the Worlds.",
            language = "Arabic / Persian",
            approximatePeriod = "1635 AD (Mughal Era)",
            significance = "This beautiful calligraphy inscription is carved on the archway, celebrating spiritual devotion and royal grace.",
            confidenceNote = "Slightly weathered due to rainwater flow, but still highly elegant and visible."
        )
    }

    private fun getFallbackTrail(city: String, hours: Int): HeritageTrail {
        return HeritageTrail(
            trailName = "The Royal ${"$"}city Landmarks Trail",
            totalDuration = "${"$"}hours hours",
            totalDistance = "4.8 km",
            difficulty = "Moderate & Delightful",
            sites = listOf(
                TrailSite(
                    order = 1,
                    name = "Historical Central Fort",
                    timeToSpend = "45 mins",
                    distanceFromPrevious = "0.0 km",
                    travelMode = "Auto-Rickshaw",
                    highlight = "The magnificent imperial massive main entrance gateway.",
                    bestPhotoSpot = "Directly centered inside the outer courtyard looking upward."
                ),
                TrailSite(
                    order = 2,
                    name = "Sacred Heritage Mosque",
                    timeToSpend = "30 mins",
                    distanceFromPrevious = "1.5 km",
                    travelMode = "Walking",
                    highlight = "Fresco tile patterns and structural red domes.",
                    bestPhotoSpot = "From the eastern minaret viewpoint during midday light."
                )
            ),
            localFoodStop = LocalFoodStop(
                name = "Al-Habib Heritage Tikka",
                dish = "Traditional Spicy Seekh Kababs & Khameeri Roti",
                why = "A majestic local culinarian treasure to reward you after walking historical routes."
            ),
            trailStory = "This customized trail takes you through the main dynastic marvel sites of ${"$"}city within your available time limit of ${"$"}hours hours, combining ancient forts, spiritual mosques, and legendary local street delicacies."
        )
    }

    private fun getFallbackQuest(city: String): WeeklyQuest {
        return WeeklyQuest(
            questTitle = "The Grand ${"$"}city Dynastic Challenge",
            theme = "Explorations of Imperial Archways & Fortresses",
            difficulty = "Explorer",
            timeRequired = "Weekend (2 Days)",
            sitesToVisit = listOf("Badshahi Mosque", "Lahore Fort (Shahi Qila)", "Hiran Minar"),
            mainChallenge = "Find and click explored on any two of these grand structures to confirm your visit, then save your custom travel notes!",
            bonusChallenge = "Identify an calligraphy inscription or carve at any site and write its local meaning.",
            rewardBadge = "${"$"}city Heritage Champion 🏆",
            funHistoryHook = "Did you know that the royal walls and bastions of these monuments were designed with special natural resonance acoustical features to alert guards of distant footsteps?"
        )
    }

    private fun getFallbackConservation(): ConservationRiskReport {
        return ConservationRiskReport(
            overallCondition = "Good / Fair",
            damageObserved = listOf(
                DamageObservation(
                    type = "Minor weathering & surface rust",
                    severity = "Low",
                    locationInImage = "Top left exterior stone wall",
                    description = "Surface discoloration due to rain and humidity exposure."
                )
            ),
            preservationUrgency = "Monitoring needed",
            recommendedAction = "Apply localized non-acidic clean-up washes to preserve raw masonry surfaces.",
            whatVisitorCanDo = "Avoid placing hands directly on historical murals and report active scribblers to custodians.",
            heritageAtRiskScore = 3,
            encouragingMessage = "Thank you, stellar heritage defender! Your vigilance helps keep our historical structures alive for future generations."
        )
    }

    private fun getFallbackDiscoveryCard(siteName: String, era: String, city: String, userName: String): DiscoveryCardContent {
        return DiscoveryCardContent(
            headline = "Where Empires Rose & Echoed",
            oneLiner = "Uncovering centuries of majestic history at the heart of ${"$"}city.",
            eraLabel = "${"$"}era · Historic Pride",
            discoveryCaption = "${"$"}userName has successfully explored ${"$"}siteName! 🌟",
            hashtags = listOf("#Khoj", "#HeritageExplorer", "#Explore${"$"}city", "#PakistaniPride"),
            urduTagline = "عظمتِ رفتہ کی کھوج"
        )
    }
}