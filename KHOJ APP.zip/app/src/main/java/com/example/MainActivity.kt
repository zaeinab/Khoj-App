package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel = androidx.lifecycle.viewmodel.compose.viewModel { MainViewModel(applicationContext) }
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()

            MyApplicationTheme(darkTheme = isDarkTheme) {
                val navController = rememberNavController()

                NavHost(
                    navController = navController, 
                    startDestination = "home"
                ) {
                    composable("home") {
                        HomeScreen(navController = navController, viewModel = viewModel)
                    }
                    composable("camera") {
                        CameraScreen(navController = navController, viewModel = viewModel)
                    }
                    composable("result") {
                        ResultScreen(navController = navController, viewModel = viewModel)
                    }
                }
            }
        }
    }
}
