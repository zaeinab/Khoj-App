package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ShahiGold,
    onPrimary = Color.Black,
    secondary = GoldBeige,
    onSecondary = Color.Black,
    tertiary = AntiqueBronze,
    background = DarkEmeraldBg,
    onBackground = OnDarkSurface,
    surface = DarkSurface,
    onSurface = OnDarkSurface,
    primaryContainer = Color(0xFF383A2E), // Deeper contrast container for dark mode
    onPrimaryContainer = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF3A4E38),         // Deeper, high-contrast forest olive green
    onPrimary = Color.White,
    secondary = Color(0xFFAC7765),       // Elegant rich terracotta clay 
    onSecondary = Color.White,
    tertiary = Color(0xFF534C43),        // High-contrast deep sandstone grey
    background = Color(0xFFFAF6F0),      // Fresh pristine antique warm ivory
    onBackground = Color(0xFF1B1C17),    // Solid charcoal near-black for exceptional text contrast
    surface = Color.White,               // Pristine white cards
    onSurface = Color(0xFF1B1C17),       // solid near-black elements
    primaryContainer = Color(0xFFE6EFE5), // Crisp soft mint-emerald container background
    onPrimaryContainer = Color(0xFF1D2C1C) // Extremely deep, crystal-clear dark olive text
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
