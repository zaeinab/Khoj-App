package com.example.ui

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class SpeechManager(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            // Default to English initially
            tts?.language = Locale.US
        } else {
            Log.e("SpeechManager", "Initialization of TextToSpeech failed.")
        }
    }

    fun speak(text: String, isUrdu: Boolean) {
        if (!isInitialized || tts == null) {
            Log.e("SpeechManager", "TTS not initialized yet")
            return
        }

        // Configure locale based on selection
        val locale = if (isUrdu) {
            Locale("ur", "PK") // Urdu (Pakistan) locale
        } else {
            Locale.US
        }

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.e("SpeechManager", "Language not supported or missing data: ${locale.displayLanguage}")
            // Fallback to default Locale if Urdu PK is missing
            if (isUrdu) {
                tts?.setLanguage(Locale("ur")) 
            }
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "KHOJ_SPEECH_ID")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}
