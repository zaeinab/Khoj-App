package com.example

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.ui.InfoSectionCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent { 
      MyApplicationTheme { 
        InfoSectionCard(
          isUrdu = false,
          titleEn = "The Story & Foundations",
          titleUr = "تاریخ اور پس منظر",
          textEn = "A massive Mughal-era mosque built by Emperor Aurangzeb, famous for its red sandstone architecture.",
          textUr = "مغل دور کی ایک بڑی مسجد جسے شہنشاہ اورنگزیب نے بنوایا تھا، جو اپنے لال پتھر کے طرز تعمیر کے لئے مشہور ہے۔",
          icon = Icons.Default.MenuBook
        )
      } 
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
