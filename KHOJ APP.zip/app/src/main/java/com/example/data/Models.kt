package com.example.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

// --- Gemini API Models for REST interface ---

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null,
    @Json(name = "inlineData") val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "responseSchema") val responseSchema: ResponseSchema? = null,
    @Json(name = "temperature") val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class ResponseSchema(
    @Json(name = "type") val type: String, // "OBJECT", "ARRAY", "STRING" etc.
    @Json(name = "properties") val properties: Map<String, SchemaProperty>? = null,
    @Json(name = "required") val required: List<String>? = null,
    @Json(name = "items") val items: ResponseSchema? = null
)

@JsonClass(generateAdapter = true)
data class SchemaProperty(
    @Json(name = "type") val type: String,
    @Json(name = "description") val description: String? = null,
    @Json(name = "items") val items: ResponseSchema? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content?
)

// --- Our custom structured response representing details of a historical monument ---

@JsonClass(generateAdapter = true)
data class MonumentDetails(
    @Json(name = "site_name") val siteName: String = "",
    @Json(name = "site_name_ur") val siteNameUrBacking: String? = null,
    @Json(name = "era") val era: String = "",
    @Json(name = "era_ur_backing") val eraUrBacking: String? = null,
    @Json(name = "city") val city: String = "",
    @Json(name = "city_ur") val cityUrBacking: String? = null,
    @Json(name = "confidence") val confidence: String = "",
    @Json(name = "short_description") val shortDescription: String = "",
    @Json(name = "short_description_ur") val shortDescriptionUrBacking: String? = null,
    @Json(name = "historical_narrative") val historicalNarrative: String = "",
    @Json(name = "historical_narrative_ur") val historicalNarrativeUrBacking: String? = null,
    @Json(name = "at_its_peak") val atItsPeak: String = "",
    @Json(name = "at_its_peak_ur") val atItsPeakUrBacking: String? = null,
    @Json(name = "decline") val decline: String = "",
    @Json(name = "decline_ur") val declineUrBacking: String? = null,
    @Json(name = "fun_fact") val funFact: String = "",
    @Json(name = "fun_fact_ur") val funFactUrBacking: String? = null,
    @Json(name = "visit_tips") val visitTips: String = "",
    @Json(name = "visit_tips_ur") val visitTipsUrBacking: String? = null,
    @Json(name = "nearby_sites") val nearbySites: List<String>? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null,

    // New keys for exact matching of user requested schema
    @Json(name = "name_en") val nameEnNew: String? = null,
    @Json(name = "name_ur") val nameUrNew: String? = null,
    @Json(name = "era_en") val eraEnNew: String? = null,
    @Json(name = "era_ur") val eraUrNew: String? = null,
    @Json(name = "history_en") val historyEnNew: String? = null,
    @Json(name = "history_ur") val historyUrNew: String? = null,
    @Json(name = "peak_en") val peakEnNew: String? = null,
    @Json(name = "peak_ur") val peakUrNew: String? = null,
    @Json(name = "connection_en") val connectionEnNew: String? = null,
    @Json(name = "connection_ur") val connectionUrNew: String? = null
) {
    // Custom getters/properties for complete backward compatibility with existing code!
    val nameEn: String get() = nameEnNew ?: siteName
    val nameUr: String get() = nameUrNew ?: siteNameUrBacking ?: siteName
    val eraEn: String get() = eraEnNew ?: era
    val eraUr: String get() = eraUrNew ?: eraUrBacking ?: era
    val historyEn: String get() = historyEnNew ?: historicalNarrative
    val historyUr: String get() = historyUrNew ?: historicalNarrativeUrBacking ?: historicalNarrative
    val peakEn: String get() = peakEnNew ?: atItsPeak
    val peakUr: String get() = peakUrNew ?: atItsPeakUrBacking ?: atItsPeak
    val connectionEn: String get() = connectionEnNew ?: "🔍 Decline:\n$decline\n\n📌 Fun Fact:\n$funFact\n\n💡 Tips:\n$visitTips"
    val connectionUr: String get() = connectionUrNew ?: "🔍 زوال کا سبب:\n${declineUrBacking ?: decline}\n\n📌 دلچسپ حقیقت:\n${funFactUrBacking ?: funFact}\n\n💡 مشورے:\n${visitTipsUrBacking ?: visitTips}"
}

// --- Landmark model used for suggesting nearby sites ---

data class HistoricalLandmark(
    val nameEn: String,
    val nameUr: String,
    val cityEn: String,
    val cityUr: String,
    val latitude: Double,
    val longitude: Double,
    val descriptionEn: String,
    val descriptionUr: String
)

object LandmarksRegistry {
    val pakistaniLandmarks = listOf(
        HistoricalLandmark(
            nameEn = "Badshahi Mosque",
            nameUr = "بادشاہی مسجد",
            cityEn = "Lahore",
            cityUr = "لاہور",
            latitude = 31.5882,
            longitude = 74.3106,
            descriptionEn = "A massive Mughal-era mosque built by Emperor Aurangzeb, famous for its red sandstone architecture.",
            descriptionUr = "مغل دور کی ایک بڑی مسجد جسے شہنشاہ اورنگزیب نے بنوایا تھا، جو اپنے لال پتھر کے طرز تعمیر کے لئے مشہور ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Lahore Fort (Shahi Qila)",
            nameUr = "شاہی قلعہ",
            cityEn = "Lahore",
            cityUr = "لاہور",
            latitude = 31.5880,
            longitude = 74.3154,
            descriptionEn = "A citadel showcasing the rich architecture of the Mughal, Sikh, and British eras, including Sheesh Mahal.",
            descriptionUr = "مغلیہ، سکھ، اور برطانوی دور کے شاندار طرز تعمیر کا شاہکار قلعہ، جس میں شیشہ محل بھی شامل ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Shalimar Gardens",
            nameUr = "شالامار باغ",
            cityEn = "Lahore",
            cityUr = "لاہور",
            latitude = 31.5855,
            longitude = 74.3819,
            descriptionEn = "A Mughal garden complex built by Emperor Shah Jahan, featuring water terraces and fountains.",
            descriptionUr = "شہنشاہ شاہ جہاں کا بنوایا ہوا مغلیہ باغ، جو پانی کے خوبصورت تالابوں اور فواروں کے لیے مشہور ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Wazir Khan Mosque",
            nameUr = "مسجد وزیر خان",
            cityEn = "Lahore",
            cityUr = "لاہور",
            latitude = 31.5828,
            longitude = 74.3214,
            descriptionEn = "An intricately decorated mosque built during the reign of Shah Jahan, known for its vibrant tile-work.",
            descriptionUr = "شاہ جہاں کے دور میں تعمیر ہونے والی انتہائی خوبصورت مسجد، جو اپنی رنگین ٹائلوں کے کام کے لیے مشہور ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Faisal Mosque",
            nameUr = "فیصل مسجد",
            cityEn = "Islamabad",
            cityUr = "اسلام آباد",
            latitude = 33.7299,
            longitude = 73.0373,
            descriptionEn = "An iconic contemporary mosque resembling a Bedouin tent, situated at the foothills of Margalla.",
            descriptionUr = "بدوؤں کے خیمے سے مشابہت رکھنے والی ایک جدید مسجد، جو مارگلہ پہاڑیوں کے دامن میں واقع ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Rohtas Fort",
            nameUr = "قلعہ روہتاس",
            cityEn = "Jhelum",
            cityUr = "جہلم",
            latitude = 32.9657,
            longitude = 73.5758,
            descriptionEn = "A grand 16th-century fortress built by Sher Shah Suri, representing exceptional military architecture.",
            descriptionUr = "سولہویں صدی کا ایک عظیم الشان قلعہ جسے شیر شاہ سوری نے بنوایا تھا، جو فوجی فن تعمیر کا بہترین نمونہ ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Mohenjo-daro",
            nameUr = "موئن جو دڑو",
            cityEn = "Larkana",
            cityUr = "لاڑکانہ",
            latitude = 27.3294,
            longitude = 68.1388,
            descriptionEn = "An archaeological site of the Indus Valley Civilization, dating back to 2500 BCE with advanced urban planning.",
            descriptionUr = "وادی سندھ کی تہذیب کا ایک قدیم ترین آثارِ قدیمہ، جو ۲۵۰۰ قبل مسیح پرانا اور جدید شہری منصوبہ بندی کا حامل ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Katas Raj Temples",
            nameUr = "کٹاس راج مندر",
            cityEn = "Chakwal",
            cityUr = "چکوال",
            latitude = 32.7237,
            longitude = 72.9515,
            descriptionEn = "A complex of ancient Hindu temples surrounding a sacred pond, rich with legendary spiritual significance.",
            descriptionUr = "قدیم ہندو مندروں کا ایک سلسلہ جو ایک مقدس تالاب کے گرد واقع ہے، اور کئی روحانی داستانوں سے وابستہ ہے۔"
        ),
        HistoricalLandmark(
            nameEn = "Taxila Ruins",
            nameUr = "ٹیکسلا کے آثار",
            cityEn = "Taxila",
            cityUr = "ٹیکسلا",
            latitude = 33.7461,
            longitude = 72.8123,
            descriptionEn = "Ancient city and archaeological sites dating back to Gandhara civilization, once a world-renowned center of learning.",
            descriptionUr = "گندھارا تہذیب کا ایک قدیم شہر اور تاریخی مقام، جو کبھی علم و دانش کا عالمی مرکز سمجھا جاتا تھا۔"
        ),
        HistoricalLandmark(
            nameEn = "Minar-e-Pakistan",
            nameUr = "مینار پاکستان",
            cityEn = "Lahore",
            cityUr = "لاہور",
            latitude = 31.5925,
            longitude = 74.3095,
            descriptionEn = "A towering monument built on the site where the Lahore Resolution of 1940 was passed, demanding a separate state.",
            descriptionUr = "ایک بلند و بالا مینار جو اس مقام پر تعمیر کیا گیا جہاں ۱۹۴۰ء کی قراردادِ لاہور منظور ہوئی تھی۔"
        ),
        HistoricalLandmark(
            nameEn = "Derawar Fort",
            nameUr = "قلعہ دراوڑ",
            cityEn = "Cholistan",
            cityUr = "چولستان",
            latitude = 28.7671,
            longitude = 71.3323,
            descriptionEn = "A monumental square fortress situated in the heart of Cholistan Desert, featuring 40 majestic bastions.",
            descriptionUr = "صحراِ چولستان کے دل میں واقع ایک عظیم قلعہ، جس کے ۴۰ شاندار برج میلوں دور سے نظر آتے ہیں۔"
        ),
        HistoricalLandmark(
            nameEn = "Hiran Minar",
            nameUr = "ہرن مینار",
            cityEn = "Sheikhupura",
            cityUr = "شیخوپورہ",
            latitude = 31.7454,
            longitude = 74.0041,
            descriptionEn = "A Mughal-era monument built by Emperor Jahangir as a memorial to his beloved pet antelope, Mansraj.",
            descriptionUr = "شہنشاہ جہانگیر کا اپنے پالتو ہرن 'منس راج' کی یاد میں بنوایا ہوا ایک تاریخی مینار اور تالاب۔"
        ),
        HistoricalLandmark(
            nameEn = "Mazar-e-Quaid",
            nameUr = "مزار قائد",
            cityEn = "Karachi",
            cityUr = "کراچی",
            latitude = 24.8744,
            longitude = 67.0400,
            descriptionEn = "The magnificent marble mausoleum of Quaid-e-Azam Muhammad Ali Jinnah, founder of Pakistan.",
            descriptionUr = "بانیِ پاکستان قائدِ اعظم محمد علی جناح کا خوبصورت اور شاندار سنگِ مرمر کا مزار۔"
        ),
        HistoricalLandmark(
            nameEn = "Baltit Fort",
            nameUr = "بلتت قلعہ",
            cityEn = "Hunza",
            cityUr = "ہنزہ",
            latitude = 36.3263,
            longitude = 74.6713,
            descriptionEn = "An ancient Tibetan-inspired fortress positioned high above Karimabad, mirroring centuries of northern mountain dynasties.",
            descriptionUr = "ایک قدیم تاریخی قلعہ جو وادی ہنزہ میں کریم آباد کے اوپر واقع ہے، اور تبت کے طرز تعمیر سے متاثر ہے۔"
        )
    )
}

// --- Dynamic Interactive Feature Data Classes ---

@JsonClass(generateAdapter = true)
data class ScriptDecipherResult(
    @Json(name = "script_type") val scriptType: String,
    @Json(name = "transcription") val transcription: String,
    @Json(name = "translation") val translation: String,
    @Json(name = "language") val language: String,
    @Json(name = "approximate_period") val approximatePeriod: String,
    @Json(name = "significance") val significance: String,
    @Json(name = "confidence_note") val confidenceNote: String? = null,
    @Json(name = "error") val error: String? = null,
    @Json(name = "message") val message: String? = null
)

@JsonClass(generateAdapter = true)
data class HeritageTrail(
    @Json(name = "trail_name") val trailName: String,
    @Json(name = "total_duration") val totalDuration: String,
    @Json(name = "total_distance") val totalDistance: String,
    @Json(name = "difficulty") val difficulty: String,
    @Json(name = "sites") val sites: List<TrailSite>,
    @Json(name = "local_food_stop") val localFoodStop: LocalFoodStop,
    @Json(name = "trail_story") val trailStory: String
)

@JsonClass(generateAdapter = true)
data class TrailSite(
    @Json(name = "order") val order: Int,
    @Json(name = "name") val name: String,
    @Json(name = "time_to_spend") val timeToSpend: String,
    @Json(name = "distance_from_previous") val distanceFromPrevious: String,
    @Json(name = "travel_mode") val travelMode: String,
    @Json(name = "highlight") val highlight: String,
    @Json(name = "best_photo_spot") val bestPhotoSpot: String
)

@JsonClass(generateAdapter = true)
data class LocalFoodStop(
    @Json(name = "name") val name: String,
    @Json(name = "dish") val dish: String,
    @Json(name = "why") val why: String
)

@JsonClass(generateAdapter = true)
data class WeeklyQuest(
    @Json(name = "quest_title") val questTitle: String,
    @Json(name = "theme") val theme: String,
    @Json(name = "difficulty") val difficulty: String,
    @Json(name = "time_required") val timeRequired: String,
    @Json(name = "sites_to_visit") val sitesToVisit: List<String>,
    @Json(name = "main_challenge") val mainChallenge: String,
    @Json(name = "bonus_challenge") val bonusChallenge: String,
    @Json(name = "reward_badge") val rewardBadge: String,
    @Json(name = "fun_history_hook") val funHistoryHook: String
)

@JsonClass(generateAdapter = true)
data class ConservationRiskReport(
    @Json(name = "overall_condition") val overallCondition: String,
    @Json(name = "damage_observed") val damageObserved: List<DamageObservation>,
    @Json(name = "preservation_urgency") val preservationUrgency: String,
    @Json(name = "recommended_action") val recommendedAction: String,
    @Json(name = "what_visitor_can_do") val whatVisitorCanDo: String,
    @Json(name = "heritage_at_risk_score") val heritageAtRiskScore: Int,
    @Json(name = "encouraging_message") val encouragingMessage: String
)

@JsonClass(generateAdapter = true)
data class DamageObservation(
    @Json(name = "type") val type: String,
    @Json(name = "severity") val severity: String,
    @Json(name = "location_in_image") val locationInImage: String,
    @Json(name = "description") val description: String
)

@JsonClass(generateAdapter = true)
data class DiscoveryCardContent(
    @Json(name = "headline") val headline: String,
    @Json(name = "one_liner") val oneLiner: String,
    @Json(name = "era_label") val eraLabel: String,
    @Json(name = "discovery_caption") val discoveryCaption: String,
    @Json(name = "hashtags") val hashtags: List<String>,
    @Json(name = "urdu_tagline") val urduTagline: String
)
