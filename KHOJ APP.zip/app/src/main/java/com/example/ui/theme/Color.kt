package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable

// Elegant Natural Tones Palette (Bespoke Pakistan Heritage Archive Aesthetics)
val EmeraldGreen = Color(0xFF8C8E75)  // Mossy Sage Olive Green from Image
val LightEmerald = Color(0xFFA3A68B)  // Lighter Sage Moss
val ShahiGold = Color(0xFFAC7765)     // Clay/Terracotta Accent from Image
val MughalOchre = Color(0xFF9E6554)    // Burnt Sienna Clay

val BackgroundCream = Color(0xFFE5D5C1) // Warm Antique Ivory Parchment Paper
val SandStone = Color(0xFFC3B6A7)       // Muted Ash/Stone Grey
val CardSurface = Color(0xFFFAF2E6)     // Pristine Warm Light Cream

// Modern Sophisticated Dark Theme Options
val AntiqueBronze = Color(0xFFAC7765)
val GoldBeige = Color(0xFFEADCC9)
val DarkEmeraldBg = Color(0xFF1B1C17)   // Absolute Dark Slate Olive Black
val DarkSurface = Color(0xFF2A2B23)     // Warm dark gray-olive surface
val OnDarkSurface = Color(0xFFFAF2E6)

val TextPrimary: Color
    @Composable
    @ReadOnlyComposable
    get() = MaterialTheme.colorScheme.onSurface

val TextSecondary: Color
    @Composable
    @ReadOnlyComposable
    get() = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
