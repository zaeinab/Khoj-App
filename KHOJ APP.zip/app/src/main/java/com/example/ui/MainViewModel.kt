package com.example.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface ScanState {
    object Idle : ScanState
    object Scanning : ScanState
    data class Success(val details: MonumentDetails, val localImagePath: String?) : ScanState
    data class Error(val message: String) : ScanState
}

sealed interface ScriptState {
    object Idle : ScriptState
    object Deciphering : ScriptState
    data class Success(val result: ScriptDecipherResult) : ScriptState
    data class Error(val message: String) : ScriptState
}

sealed interface TrailState {
    object Idle : TrailState
    object Curating : TrailState
    data class Success(val trail: HeritageTrail) : TrailState
    data class Error(val message: String) : TrailState
}

sealed interface QuestState {
    object Idle : QuestState
    object Generating : QuestState
    data class Success(val quest: WeeklyQuest) : QuestState
    data class Error(val message: String) : QuestState
}

sealed interface ConservationState {
    object Idle : ConservationState
    object Analyzing : ConservationState
    data class Success(val report: ConservationRiskReport) : ConservationState
    data class Error(val message: String) : ConservationState
}

sealed interface DiscoveryCardState {
    object Idle : DiscoveryCardState
    object Generating : DiscoveryCardState
    data class Success(val card: DiscoveryCardContent) : DiscoveryCardState
    data class Error(val message: String) : DiscoveryCardState
}

class MainViewModel(context: Context) : ViewModel() {
    private val db = AppDatabase.getDatabase(context.applicationContext)
    private val dao = db.exploredPlaceDao

    private val sharedPrefs = context.getSharedPreferences("khoj_prefs", Context.MODE_PRIVATE)

    // State for all saved user discoveries on-disk
    val exploredPlacesList: StateFlow<List<ExploredPlace>> = dao.getAllExploredPlaces()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current scan task state
    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    // Global application language setting (True = Urdu, False = English)
    private val _isUrduMode = MutableStateFlow(false)
    val isUrduMode: StateFlow<Boolean> = _isUrduMode.asStateFlow()

    // Global theme mode switch (True = Dark, False = Light)
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    // Geographic coordinates of the user. Defaults to Lahore's coordinates.
    private val _userLocation = MutableStateFlow<Pair<Double, Double>?>(null)
    val userLocation: StateFlow<Pair<Double, Double>?> = _userLocation.asStateFlow()

    // Sorted nearby sites matching distance
    private val _nearbyLandmarks = MutableStateFlow<List<Pair<HistoricalLandmark, Double>>>(emptyList())
    val nearbyLandmarks: StateFlow<List<Pair<HistoricalLandmark, Double>>> = _nearbyLandmarks.asStateFlow()

    // Preselected Mock City center (Lahore)
    private val _selectedMockCity = MutableStateFlow("Lahore")
    val selectedMockCity: StateFlow<String> = _selectedMockCity.asStateFlow()

    init {
        // Initial setup with default location
        updateLocationFromMockCity("Lahore")
    }

    fun toggleLanguage() {
        _isUrduMode.value = !_isUrduMode.value
    }

    fun changeMockCity(city: String) {
        _selectedMockCity.value = city
        updateLocationFromMockCity(city)
    }

    private fun updateLocationFromMockCity(city: String) {
        val coords = when (city) {
            "Karachi" -> Pair(24.8607, 67.0011)
            "Islamabad" -> Pair(33.6844, 73.0479)
            "Peshawar" -> Pair(34.0151, 71.5249)
            "Quetta" -> Pair(30.1798, 66.9750)
            else -> Pair(31.5204, 74.3587) // Lahore
        }
        _userLocation.value = coords
        recalculateDistances(coords.first, coords.second)
    }

    /**
     * Attaches play-services location service listener to pull actual device coords
     */
    @SuppressLint("MissingPermission")
    fun requestDeviceLocation(context: Context) {
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
        try {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        val coords = Pair(location.latitude, location.longitude)
                        _userLocation.value = coords
                        _selectedMockCity.value = "GPS Location"
                        recalculateDistances(coords.first, coords.second)
                    }
                }
                .addOnFailureListener {
                    Log.e("MainViewModel", "GPS fetch error: ${it.message}")
                }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Recomputes landmarks' geographic distance using the Haversine formula
     */
    private fun recalculateDistances(userLat: Double, userLon: Double) {
        val computedList = LandmarksRegistry.pakistaniLandmarks.map { landmark ->
            val distance = calculateHaversineDistance(userLat, userLon, landmark.latitude, landmark.longitude)
            Pair(landmark, distance)
        }.sortedBy { it.second } // Nearest first
        _nearbyLandmarks.value = computedList
    }

    private fun calculateHaversineDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6371.0 // km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val flatDistance = earthRadius * c
        // Pakistan road/transit winding factor: scale flat crows-flight distance by 1.28x for incredibly realistic driving distance
        return flatDistance * 1.28
    }

    fun resetState() {
        _scanState.value = ScanState.Idle
    }

    /**
     * Uploads the captured or picked photo and triggers Gemini AI analysis
     */
    fun performAiAnalysis(context: Context, bitmap: Bitmap) {
        _scanState.value = ScanState.Scanning

        viewModelScope.launch {
            try {
                val details = GeminiApiClient.identifyHistoricalSite(bitmap)
                if (details != null) {
                    if (details.error == "not_a_site" || details.nameEn.contains("Unknown Site", ignoreCase = true)) {
                        _scanState.value = ScanState.Error(
                            if (_isUrduMode.value) {
                                val msg = details.historyUr.trim()
                                if (msg.isNotEmpty()) msg else "یہ کوئی تاریخی مقام معلوم نہیں ہوتا۔ براہ کرم کسی تاریخی عمارت کی تصویر لیں۔"
                            } else {
                                val msg = details.historyEn.trim()
                                if (msg.isNotEmpty()) msg else "This doesn't appear to be a historical site. Try pointing your camera at a monument, fort, mosque, or archaeological site."
                            }
                        )
                    } else {
                        // Save bitmap to local directory storage to retain it in our sqlite Room log
                        val localPath = saveImageToInternalStorage(context, bitmap)

                        // Add landmark to database log
                        val place = ExploredPlace(
                            nameEn = details.nameEn,
                            nameUr = details.nameUr,
                            eraEn = details.eraEn,
                            eraUr = details.eraUr,
                            historyEn = details.historyEn,
                            historyUr = details.historyUr,
                            peakEn = details.peakEn,
                            peakUr = details.peakUr,
                            connectionEn = details.connectionEn,
                            connectionUr = details.connectionUr,
                            imagePath = localPath,
                            latitude = _userLocation.value?.first,
                            longitude = _userLocation.value?.second
                        )
                        dao.insertExploredPlace(place)

                        _scanState.value = ScanState.Success(details, localPath)
                    }
                } else {
                    _scanState.value = ScanState.Error(
                        if (_isUrduMode.value) 
                            "تاریخی مقام کی شناخت میں ناکامی۔ براہ کرم واضح تصویر اور فعال انٹرنیٹ کنکشن چیک کریں۔"
                        else 
                            "Could not identify any historical site. Please take a clearer picture and check your Gemini API key."
                    )
                }
            } catch (e: Exception) {
                _scanState.value = ScanState.Error("Error: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Saves captured bitmap as a jpeg file inside internal app storage
     */
    private fun saveImageToInternalStorage(context: Context, bitmap: Bitmap): String? {
        return try {
            val filename = "khoj_scan_${System.currentTimeMillis()}.jpg"
            val file = File(context.filesDir, filename)
            val outputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream)
            outputStream.flush()
            outputStream.close()
            file.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun deleteExploredItem(place: ExploredPlace) {
        viewModelScope.launch {
            // Delete accompanying physical file if present
            place.imagePath?.let { path ->
                val file = File(path)
                if (file.exists()) file.delete()
            }
            dao.deleteExploredPlace(place)
        }
    }

    fun addNoteToExploredItem(place: ExploredPlace, noteText: String) {
        viewModelScope.launch {
            dao.updateExploredPlace(place.copy(note = noteText))
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            // Delete all saved image files
            exploredPlacesList.value.forEach { place ->
                place.imagePath?.let { path ->
                    val file = File(path)
                    if (file.exists()) file.delete()
                }
            }
            dao.clearAllPlaces()
        }
    }

    // --- Dynamic Interactive Chat States ---

    private val _chatMessages = MutableStateFlow<List<Pair<String, Boolean>>>(emptyList())
    val chatMessages: StateFlow<List<Pair<String, Boolean>>> = _chatMessages.asStateFlow()

    private val _isSendingChatMessage = MutableStateFlow(false)
    val isSendingChatMessage: StateFlow<Boolean> = _isSendingChatMessage.asStateFlow()

    fun resetChat(opener: String) {
        _chatMessages.value = listOf(Pair(opener, false))
    }

    fun sendChatMessage(monumentName: String, era: String, messageText: String) {
        if (messageText.isBlank()) return
        val currentList = _chatMessages.value.toMutableList()
        currentList.add(Pair(messageText, true))
        _chatMessages.value = currentList

        _isSendingChatMessage.value = true
        viewModelScope.launch {
            val response = GeminiApiClient.chatWithMonument(monumentName, era, currentList, messageText)
            _isSendingChatMessage.value = false
            val updatedList = _chatMessages.value.toMutableList()
            if (response != null) {
                updatedList.add(Pair(response, false))
            } else {
                updatedList.add(Pair(if (_isUrduMode.value) "معاف کیجیے گا، میں اس وقت جواب دینے سے قاصر ہوں۔" else "I am sorry, my old stones cannot find the answer right now.", false))
            }
            _chatMessages.value = updatedList
        }
    }

    // --- Dynamic Script Assessment State ---

    private val _scriptState = MutableStateFlow<ScriptState>(ScriptState.Idle)
    val scriptState: StateFlow<ScriptState> = _scriptState.asStateFlow()

    fun resetScriptState() {
        _scriptState.value = ScriptState.Idle
    }

    fun decipherInscription(bitmap: Bitmap) {
        _scriptState.value = ScriptState.Deciphering
        viewModelScope.launch {
            val result = GeminiApiClient.decipherAncientScript(bitmap)
            if (result != null) {
                _scriptState.value = ScriptState.Success(result)
            } else {
                _scriptState.value = ScriptState.Error("Failed to analyze inscription. Ensure text is clearly visible.")
            }
        }
    }

    // --- Dynamic Heritage Trail Planner State ---

    private val _trailState = MutableStateFlow<TrailState>(TrailState.Idle)
    val trailState: StateFlow<TrailState> = _trailState.asStateFlow()

    fun resetTrailState() {
        _trailState.value = TrailState.Idle
    }

    fun curateTrail(city: String, hours: Int) {
        _trailState.value = TrailState.Curating
        viewModelScope.launch {
            val result = GeminiApiClient.generateHeritageTrail(city, hours)
            if (result != null) {
                _trailState.value = TrailState.Success(result)
            } else {
                _trailState.value = TrailState.Error("Failed to curate custom trail. Try changing durations.")
            }
        }
    }

    // --- Dynamic Weekly Quest State ---

    private val _questState = MutableStateFlow<QuestState>(QuestState.Idle)
    val questState: StateFlow<QuestState> = _questState.asStateFlow()

    fun resetQuestState() {
        _questState.value = QuestState.Idle
    }

    fun generateQuest(city: String) {
        _questState.value = QuestState.Generating
        viewModelScope.launch {
            val result = GeminiApiClient.generateWeeklyQuest(city)
            if (result != null) {
                _questState.value = QuestState.Success(result)
            } else {
                _questState.value = QuestState.Error("Failed to generate weekly challenge.")
            }
        }
    }

    // --- Dynamic Conservation Check State ---

    private val _conservationState = MutableStateFlow<ConservationState>(ConservationState.Idle)
    val conservationState: StateFlow<ConservationState> = _conservationState.asStateFlow()

    fun resetConservationState() {
        _conservationState.value = ConservationState.Idle
    }

    fun analyzeConservation(bitmap: Bitmap) {
        _conservationState.value = ConservationState.Analyzing
        viewModelScope.launch {
            val result = GeminiApiClient.analyzeConservationRisk(bitmap)
            if (result != null) {
                _conservationState.value = ConservationState.Success(result)
            } else {
                _conservationState.value = ConservationState.Error("Failed to run conservation check.")
            }
        }
    }

    // --- Dynamic Discovery Card State ---

    private val _discoveryCardState = MutableStateFlow<DiscoveryCardState>(DiscoveryCardState.Idle)
    val discoveryCardState: StateFlow<DiscoveryCardState> = _discoveryCardState.asStateFlow()

    fun resetDiscoveryCardState() {
        _discoveryCardState.value = DiscoveryCardState.Idle
    }

    fun generateDiscoveryCard(siteName: String, era: String, city: String, userName: String) {
        _discoveryCardState.value = DiscoveryCardState.Generating
        viewModelScope.launch {
            val result = GeminiApiClient.generateDiscoveryCard(siteName, era, city, userName)
            if (result != null) {
                _discoveryCardState.value = DiscoveryCardState.Success(result)
            } else {
                _discoveryCardState.value = DiscoveryCardState.Error("Failed to generate discovery card.")
            }
        }
    }

    // --- Interactive Active Quest Tracker & Badges system ---

    private val _activeQuest = MutableStateFlow<WeeklyQuest?>(null)
    val activeQuest: StateFlow<WeeklyQuest?> = _activeQuest.asStateFlow()

    private val _completedSites = MutableStateFlow<Set<String>>(emptySet())
    val completedSites: StateFlow<Set<String>> = _completedSites.asStateFlow()

    private val _mainChallengeCompleted = MutableStateFlow(false)
    val mainChallengeCompleted: StateFlow<Boolean> = _mainChallengeCompleted.asStateFlow()

    private val _bonusChallengeCompleted = MutableStateFlow(false)
    val bonusChallengeCompleted: StateFlow<Boolean> = _bonusChallengeCompleted.asStateFlow()

    private val _earnedBadges = MutableStateFlow<List<String>>(emptyList())
    val earnedBadges: StateFlow<List<String>> = _earnedBadges.asStateFlow()

    // 7-Day Streak completed days (values 1 to 7)
    private val _questStreak = MutableStateFlow<Set<Int>>(emptySet())
    val questStreak: StateFlow<Set<Int>> = _questStreak.asStateFlow()

    fun exploreToday(siteName: String? = null) {
        val calendar = java.util.Calendar.getInstance()
        val dayOfWeek = calendar.get(java.util.Calendar.DAY_OF_WEEK)
        val mappedDay = when (dayOfWeek) {
            java.util.Calendar.MONDAY -> 1
            java.util.Calendar.TUESDAY -> 2
            java.util.Calendar.WEDNESDAY -> 3
            java.util.Calendar.THURSDAY -> 4
            java.util.Calendar.FRIDAY -> 5
            java.util.Calendar.SATURDAY -> 6
            java.util.Calendar.SUNDAY -> 7
            else -> 1
        }
        
        val currentStreak = _questStreak.value.toMutableSet()
        currentStreak.add(mappedDay)
        _questStreak.value = currentStreak

        siteName?.let { name ->
            val quest = _activeQuest.value
            if (quest != null) {
                val matchedSite = quest.sitesToVisit.firstOrNull { 
                    it.lowercase().contains(name.lowercase()) || name.lowercase().contains(it.lowercase())
                }
                if (matchedSite != null) {
                    val currentSites = _completedSites.value.toMutableSet()
                    currentSites.add(matchedSite)
                    _completedSites.value = currentSites
                }
            }
        }
    }

    fun toggleStreakDay(day: Int) {
        val current = _questStreak.value.toMutableSet()
        if (current.contains(day)) {
            current.remove(day)
        } else {
            current.add(day)
        }
        _questStreak.value = current
    }

    fun acceptQuest(quest: WeeklyQuest) {
        _activeQuest.value = quest
        _completedSites.value = emptySet()
        _mainChallengeCompleted.value = false
        _bonusChallengeCompleted.value = false
        _questStreak.value = emptySet()
    }

    fun toggleQuestSiteCompleted(siteName: String) {
        val current = _completedSites.value.toMutableSet()
        if (current.contains(siteName)) {
            current.remove(siteName)
        } else {
            current.add(siteName)
        }
        _completedSites.value = current
    }

    fun setMainChallengeCompleted(completed: Boolean) {
        _mainChallengeCompleted.value = completed
    }

    fun setBonusChallengeCompleted(completed: Boolean) {
        _bonusChallengeCompleted.value = completed
    }

    fun claimQuestBadge(badgeName: String) {
        val badges = _earnedBadges.value.toMutableList()
        if (!badges.contains(badgeName)) {
            badges.add(badgeName)
            _earnedBadges.value = badges
        }
        // Gracefully clean up active quest once progress successfully completed!
        _activeQuest.value = null
        _completedSites.value = emptySet()
        _mainChallengeCompleted.value = false
        _bonusChallengeCompleted.value = false
        _questStreak.value = emptySet()
    }

    fun removeActiveQuest() {
        _activeQuest.value = null
        _completedSites.value = emptySet()
        _mainChallengeCompleted.value = false
        _bonusChallengeCompleted.value = false
        _questStreak.value = emptySet()
    }
}
