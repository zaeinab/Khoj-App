package com.example.ui

import android.Manifest
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.data.ExploredPlace
import com.example.data.HistoricalLandmark
import com.example.data.LandmarksRegistry
import com.example.ui.theme.*
import java.io.File
import java.io.InputStream
import java.io.FileOutputStream
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.TextStyle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

// Travel duration estimator based on driving/walking
fun formatTravelTime(distanceKm: Double, isUrdu: Boolean): String {
    val driveSpeed = 45.0 // km/h
    val totalMins = (distanceKm / driveSpeed * 60.0).toInt().coerceAtLeast(1)
    return if (isUrdu) {
        if (totalMins < 60) {
            "🚗 سفر نردیک: $totalMins منٹ گاڑی سے"
        } else {
            val hrs = totalMins / 60
            val mins = totalMins % 60
            "🚗 سفر نردیک: $hrs گھنٹہ $mins منٹ گاڑی سے"
        }
    } else {
        if (totalMins < 60) {
            "🚗 Approx. $totalMins min drive"
        } else {
            val hrs = totalMins / 60
            val mins = totalMins % 60
            "🚗 Approx. $hrs hr $mins min drive"
        }
    }
}

// Breathtaking vintage painterly illustrations mapping to Pakistani destinations
fun getPrimeGloryPaintingUrl(monumentName: String): String {
    val name = monumentName.lowercase()
    return when {
        name.contains("badshahi") -> "https://images.unsplash.com/photo-1596422846543-75c6fc197f07?q=80&w=800"
        name.contains("shahi qila") || name.contains("lahore fort") -> "https://images.unsplash.com/photo-1590073844006-33379778ae09?q=80&w=800"
        name.contains("shalimar") -> "https://images.unsplash.com/photo-1621252179027-94459d278660?q=80&w=800"
        name.contains("wazir khan") -> "https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=800"
        name.contains("faisal mosque") -> "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=800"
        name.contains("rohtas") -> "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?q=80&w=800"
        name.contains("mohenjo") -> "https://images.unsplash.com/photo-1582967788606-a171c1080cb0?q=80&w=800"
        name.contains("katas raj") -> "https://images.unsplash.com/photo-1518638150341-db16b8b082aa?q=80&w=800"
        name.contains("taxila") -> "https://images.unsplash.com/photo-1608962714022-6b9449f80962?q=80&w=800"
        name.contains("minar") -> "https://images.unsplash.com/photo-1528164344705-47542687000d?q=80&w=800"
        name.contains("derawar") -> "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=800"
        name.contains("hiran minar") -> "https://images.unsplash.com/photo-1542401886-65d6c61db217?q=80&w=800"
        name.contains("mausoleum") || name.contains("quaid") || name.contains("mazar") -> "https://images.unsplash.com/photo-1501854140801-50d01698950b?q=80&w=800"
        name.contains("baltit") || name.contains("hunza") -> "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800"
        name.contains("mosque") -> "https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=800"
        name.contains("fort") || name.contains("qila") -> "https://images.unsplash.com/photo-1590073844006-33379778ae09?q=80&w=800"
        name.contains("temple") || name.contains("mandir") -> "https://images.unsplash.com/photo-1518638150341-db16b8b082aa?q=80&w=800"
        else -> "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=800" // Classic architectural abstract painting
    }
}

// --- MAIN PORTAL SCREEN (BILINGUAL HOME) ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isUrdu by viewModel.isUrduMode.collectAsState()
    val exploredList by viewModel.exploredPlacesList.collectAsState()
    val nearbyLandmarks by viewModel.nearbyLandmarks.collectAsState()
    val userCoords by viewModel.userLocation.collectAsState()
    val mockCity by viewModel.selectedMockCity.collectAsState()
    val earnedBadges by viewModel.earnedBadges.collectAsState()

    var activeDetailLandmark by remember { mutableStateOf<HistoricalLandmark?>(null) }
    var noteEditingPlace by remember { mutableStateOf<ExploredPlace?>(null) }
    var activeSavedDetailPlace by remember { mutableStateOf<ExploredPlace?>(null) }

    // Dialog state controllers for Home Screen AI Features
    var showMonumentChat by remember { mutableStateOf(false) }
    var showScriptDecipher by remember { mutableStateOf(false) }
    var showQuestMaster by remember { mutableStateOf(false) }
    var showConservation by remember { mutableStateOf(false) }
    var showDiscoveryCard by remember { mutableStateOf(false) }

    var assessmentTypePending by remember { mutableStateOf<String?>(null) } // "decipher" or "conservation"
    
    val customImageAssessmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = handleSelectedUri(context, uri)
            if (bitmap != null) {
                val cacheFile = File(context.cacheDir, "chosen_assessment.png")
                try {
                    val out = FileOutputStream(cacheFile)
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.flush()
                    out.close()
                    if (assessmentTypePending == "decipher") {
                        showScriptDecipher = true
                    } else if (assessmentTypePending == "conservation") {
                        showConservation = true
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Error processing chosen image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Shorthand translations based on active language mode
    val appTitle = if (isUrdu) "خوج" else "KHOJ"
    val appSubtitle = if (isUrdu) "پاکستان کے گمشدہ تاریخی مقامات" else "Pakistan's Lost History"
    val scanBtnText = if (isUrdu) "مقام اسکین کریں" else "Scan Historical Site"
    val galleryBtnText = if (isUrdu) "گیلری سے منتخب کریں" else "Browse Gallery"
    val exploredCountText = if (isUrdu) "آپ اب تک ${exploredList.size} مقامات دریافت کر چکے ہیں۔" else "You've successfully discovered ${exploredList.size} site(s)!"
    
    // Gallery picker handler
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = handleSelectedUri(context, uri)
            if (bitmap != null) {
                viewModel.performAiAnalysis(context, bitmap)
                navController.navigate("result")
            } else {
                Toast.makeText(context, "Error processing image file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Permission launcher for Camera and Location
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineLocationGranted || coarseLocationGranted) {
            viewModel.requestDeviceLocation(context)
            Toast.makeText(context, "Location synced successfully!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Location permission denied. Using selected city instead.", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = appTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 28.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = appSubtitle,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                ),
                actions = {
                    val isDark by viewModel.isDarkTheme.collectAsState()

                    // Theme Switcher Button (Day / Night view)
                    IconButton(
                        onClick = { viewModel.toggleDarkTheme() },
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Beautiful Bilingual Switcher
                    IconButton(
                        onClick = { viewModel.toggleLanguage() },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Text(
                            text = if (isUrdu) "EN" else "اردو",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = modifier
                    .fillMaxHeight()
                    .widthIn(max = 680.dp)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
            // --- HEADER STATE & BUTTONS PANEL ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageOfMonumentIcon(),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = exploredCountText,
                            color = Color.White,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { navController.navigate("camera") },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 12.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Camera, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = scanBtnText, color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { galleryLauncher.launch("image/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 12.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = galleryBtnText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // --- LOCATION & MOCKING CONTROLLER ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "موجودہ مقام بدلیں" else "Active Coordinates",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            
                            // GPS Sync Button
                            Button(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("GPS Sync", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isUrdu) "آس پاس کے تاریخی مقامات جاننے کے لئے اپنا شہر منتخب کریں یا GPS سنک کریں۔" else "Select a city to calculate relative distance or use GPS tracker:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        // Horizontal city selector row
                        val cities = listOf("Lahore", "Karachi", "Islamabad", "Peshawar", "Quetta")
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(cities) { city ->
                                val active = mockCity == city
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer)
                                        .clickable { viewModel.changeMockCity(city) }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = if (isUrdu) translateCity(city) else city,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (active) Color.White else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                        
                        userCoords?.let {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${if (isUrdu) "فعال مقام" else "Location"}: Lat ${"%.4f".format(it.first)}° | Lon ${"%.4f".format(it.second)}° ($mockCity)",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // --- ACTIVE WEEKLY QUEST TRACKER CARD ---
            item {
                val activeQuest by viewModel.activeQuest.collectAsState()
                val completedSites by viewModel.completedSites.collectAsState()
                val mainChallengeCompleted by viewModel.mainChallengeCompleted.collectAsState()
                val bonusChallengeCompleted by viewModel.bonusChallengeCompleted.collectAsState()
                
                activeQuest?.let { quest ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        border = BorderStroke(2.dp, ShahiGold)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isUrdu) "🏆 جاری ہفتہ وار تلاش" else "🏆 Active Weekly Quest",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = quest.questTitle,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                IconButton(onClick = { viewModel.removeActiveQuest() }) {
                                    Icon(Icons.Default.Close, contentDescription = "Cancel Quest", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = quest.funHistoryHook,
                                fontSize = 12.sp,
                                fontStyle = FontStyle.Italic,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                            
                            Spacer(modifier = Modifier.height(14.dp))
                            
                            Text(
                                text = if (isUrdu) "اهداف چیک لسٹ (کلک کر کے نشان زد کریں):" else "Checkpoint Goals (Tap to mark completed):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            
                            quest.sitesToVisit.forEach { site ->
                                val isDone = completedSites.contains(site)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.toggleQuestSiteCompleted(site) }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Checkbox(
                                        checked = isDone,
                                        onCheckedChange = { viewModel.toggleQuestSiteCompleted(site) },
                                        colors = CheckboxDefaults.colors(checkedColor = EmeraldGreen, uncheckedColor = ShahiGold)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = site,
                                        fontSize = 13.sp,
                                        color = if (isDone) TextSecondary else TextPrimary,
                                        style = if (isDone) TextStyle(textDecoration = TextDecoration.LineThrough) else TextStyle.Default
                                    )
                                }
                            }
                            
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setMainChallengeCompleted(!mainChallengeCompleted) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = mainChallengeCompleted,
                                    onCheckedChange = { viewModel.setMainChallengeCompleted(it) },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldGreen, uncheckedColor = ShahiGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isUrdu) "بنیادی مقصد" else "Main Objective",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ShahiGold
                                    )
                                    Text(
                                        text = quest.mainChallenge,
                                        fontSize = 12.sp,
                                        color = if (mainChallengeCompleted) TextSecondary else TextPrimary,
                                        style = if (mainChallengeCompleted) TextStyle(textDecoration = TextDecoration.LineThrough) else TextStyle.Default
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setBonusChallengeCompleted(!bonusChallengeCompleted) }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = bonusChallengeCompleted,
                                    onCheckedChange = { viewModel.setBonusChallengeCompleted(it) },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldGreen, uncheckedColor = ShahiGold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isUrdu) "اضافی چیلنج (بونس)" else "Bonus Challenge Goals",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ShahiGold
                                    )
                                    Text(
                                        text = quest.bonusChallenge,
                                        fontSize = 12.sp,
                                        color = if (bonusChallengeCompleted) TextSecondary else TextPrimary,
                                        style = if (bonusChallengeCompleted) TextStyle(textDecoration = TextDecoration.LineThrough) else TextStyle.Default
                                    )
                                }
                            }
                            
                            val totalCheckpoints = quest.sitesToVisit.size + 2
                            val completedCount = completedSites.size + (if (mainChallengeCompleted) 1 else 0) + (if (bonusChallengeCompleted) 1 else 0)
                            val progressFactor = if (totalCheckpoints > 0) completedCount.toFloat() / totalCheckpoints else 0f
                            
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if (isUrdu) "تلاش کی تکمیل: ${ (progressFactor * 100).toInt() }%" else "Quest Progress: ${(progressFactor * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = "$completedCount/$totalCheckpoints",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = progressFactor,
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = ShahiGold,
                                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            )
                            
                            if (progressFactor >= 1f) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        viewModel.claimQuestBadge(quest.rewardBadge)
                                        Toast.makeText(context, if (isUrdu) "معرکہ ختم! آپ نے ${quest.rewardBadge} تمغہ حاصل کر لیا! 🎖️" else "Quest completed! You've unlocked the ${quest.rewardBadge} badge! 🎖️", Toast.LENGTH_LONG).show()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isUrdu) "تمغہ وصول کریں اور مکمل کریں!" else "Claim Badge & Complete Quest!",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- 7-DAY EXPLORATION STREAK CARD (ALWAYS VISIBLE) ---
            item {
                val questStreak by viewModel.questStreak.collectAsState()
                val context = LocalContext.current
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, ShahiGold.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "📅 ہفتہ وار چیلنج کی کارکردگی (7 دن کا سلسلہ)" else "📅 7-Day Exploration Streak",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        // Row of 7 Days representing Monday to Sunday
                        val daysListEn = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                        val daysListUr = listOf("پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ", "اتوار")
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (i in 1..7) {
                                val isCompleted = questStreak.contains(i)
                                val dayLabel = if (isUrdu) daysListUr[i-1] else daysListEn[i-1]
                                
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { viewModel.toggleStreakDay(i) }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isCompleted) MaterialTheme.colorScheme.primary 
                                                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                                            )
                                            .border(
                                                width = if (isCompleted) 2.dp else 1.dp,
                                                color = if (isCompleted) ShahiGold else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isCompleted) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Day $i Explored",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        } else {
                                            Text(
                                                text = "$i",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = dayLabel,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                         
                        // Add a quick action button to mark "Today" as explored
                        Button(
                            onClick = {
                                val calendar = java.util.Calendar.getInstance()
                                val dayOfWeek = calendar.get(java.util.Calendar.DAY_OF_WEEK)
                                val mappedDay = when (dayOfWeek) {
                                    java.util.Calendar.MONDAY -> 1
                                    java.util.Calendar.TUESDAY -> 2
                                    java.util.Calendar.WEDNESDAY -> 3
                                    java.util.Calendar.THURSDAY -> 4
                                    java.util.Calendar.FRIDAY -> 5
                                    java.util.Calendar.SATURDAY -> 6
                                    java.util.Calendar.SUNDAY -> 7
                                    else -> 1
                                }
                                if (!questStreak.contains(mappedDay)) {
                                    viewModel.toggleStreakDay(mappedDay)
                                    Toast.makeText(context, if (isUrdu) "آج کی مسلسل چیلنج کی کارکردگی درج کر لی گئی ہے!" else "Logged exploration streak for today!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, if (isUrdu) "آج کا دن پہلے ہی درج ہو چکا ہے!" else "Today's exploration is already logged!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp, horizontal = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "آج کا چیلنج مقام دریافت کر لیا ہے! (سلسلہ روشن کریں)" else "I Explored / Visited a Quest Site Today!",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // --- AI HERITAGE COMPANION SUITE ON HOME PAGE ---
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, ShahiGold.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = ShahiGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "اے آئی ورثہ معاونین" else "AI Heritage Companion Suite",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isUrdu) 
                                "تاریخی عمارت سے بات چیت، قدیم نقوش کا ترجمہ، نئی ہفتہ وار تلاش شروع کریں یا ورثہ حفاظتی جائزہ لیں۔" 
                                else "Interact with the monument, decode ancient scripts, complete quests, or analyze conservation health with AI.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        
                        Spacer(modifier = Modifier.height(14.dp))
                        
                        // Dynamically map current city landmark as focus
                        val selectedLandmark = nearbyLandmarks.firstOrNull()?.first ?: LandmarksRegistry.pakistaniLandmarks.firstOrNull { 
                            it.cityEn.lowercase().contains(mockCity.lowercase()) 
                        } ?: LandmarksRegistry.pakistaniLandmarks.first()
                        
                        val landmarkName = selectedLandmark.nameEn
                        val landmarkEra = "Mughal Era"
                        val landmarkCity = selectedLandmark.cityEn

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Row 1: Chat with Monument & Decipher Script
                            // Row 1: Chat with Monument (Full Width)
                            Button(
                                onClick = { showMonumentChat = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isUrdu) "عمارت سے گفتگو" else "Chat to Site", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            // Row 2: Weekly Quest & Heritage Conservation Check
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showQuestMaster = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isUrdu) "ہفتہ وار تلاش" else "Weekly Quest", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { 
                                        assessmentTypePending = "conservation"
                                        customImageAssessmentLauncher.launch("image/*")
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isUrdu) "حفاظتی جائزہ" else "Heritage Health", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Row 3: Discovery Card Creation
                            Button(
                                onClick = { showDiscoveryCard = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.IosShare, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isUrdu) "شوسل کارڈ بنائیں" else "Create Active Discovery Card", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // --- SUGGESTED NEARBY HISTORICAL SITES ---
            item {
                Text(
                    text = if (isUrdu) "قریبی تاریخی مقامات" else "Suggested Nearby Monuments",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = if (isUrdu) "آپ کے موجودہ مقام سے فاصلے کے لحاظ سے ترتیب دیئے گئے۔ کارڈ پر ٹیپ کر کے تاریخ پڑھیں۔" else "Sorted by nearest distance from you. Tap cards to read description.",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(nearbyLandmarks) { (landmark, distance) ->
                        Card(
                            modifier = Modifier
                                .width(220.dp)
                                .clickable { activeDetailLandmark = landmark },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(LightEmerald, EmeraldGreen)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // Custom decorative typography element representing historic architecture
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            Icons.Default.Mosque, 
                                            contentDescription = null, 
                                            tint = ShahiGold, 
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(landmark.cityEn, color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    
                                    // Distance Badge
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(8.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(ShahiGold)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "${"%.1f".format(distance)} km",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                }
                                
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = if (isUrdu) landmark.nameUr else landmark.nameEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = if (isUrdu) "${"%.1f".format(distance)} کلومیٹر دور" else "${"%.1f".format(distance)} km away",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ShahiGold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isUrdu) landmark.descriptionUr else landmark.descriptionEn,
                                        fontSize = 11.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        color = TextSecondary,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // --- USER EXPLORATION HISTORY LOG (DB TRAVEL DIARY) ---
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isUrdu) "میرا سفرنامہ — اسکین ہسٹری" else "My Saved Discoveries",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    if (exploredList.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearHistory() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear History", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            if (exploredList.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.HistoryEdu,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isUrdu) "ابھی تک کوئی تاریخی مقام اسکین نہیں کیا گیا ہے۔ اپنا پہلا سفر نامہ درج کرنے کے لیے کیمرہ کھولیں!" else "No saved discoveries yet. Point your camera at any historical site to start your travel diary!",
                            textAlign = TextAlign.Center,
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                    }
                }
            } else {
                items(exploredList) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeSavedDetailPlace = item },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Scanned item Image preview via local internal storage path
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                if (item.imagePath != null) {
                                    val imgFile = File(item.imagePath)
                                    if (imgFile.exists()) {
                                        AsyncImage(
                                            model = imgFile,
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.align(Alignment.Center))
                                    }
                                } else {
                                    Icon(Icons.Default.Landscape, contentDescription = null, modifier = Modifier.align(Alignment.Center))
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isUrdu) item.nameUr else item.nameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (isUrdu) item.eraUr else item.eraEn,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ShahiGold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CalendarToday,
                                        contentDescription = null,
                                        modifier = Modifier.size(10.dp),
                                        tint = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(item.timestamp)),
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                                
                                // User notes snippet if present
                                item.note?.let { note ->
                                    if (note.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "✍️: $note",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.secondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                IconButton(onClick = { viewModel.deleteExploredItem(item) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f))
                                }
                                IconButton(onClick = { noteEditingPlace = item }) {
                                    Icon(Icons.Default.BorderColor, contentDescription = "Add Notes", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
            
            if (earnedBadges.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, ShahiGold.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isUrdu) "میرے حاصل کردہ تمغے" else "My Achieved Badges",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(earnedBadges) { badge ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .border(1.dp, ShahiGold, RoundedCornerShape(10.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Star, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
       }
    }

    // --- LANDMARK INFO BOTTOM DIALOG SHEET ---
    activeDetailLandmark?.let { landmark ->
        LandmarkDetailDialog(
            landmark = landmark,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { activeDetailLandmark = null }
        )
    }

    // --- EDIT TRAVEL LOG NOTES DIALOG ---
    noteEditingPlace?.let { place ->
        EditNotesDialog(
            place = place,
            viewModel = viewModel,
            onDismiss = { noteEditingPlace = null }
        )
    }

    // --- SAVED MONUMENT COMPLETE REPORT BOARD ---
    activeSavedDetailPlace?.let { place ->
        SavedPlaceReportDialog(
            place = place,
            viewModel = viewModel,
            isUrdu = isUrdu,
            onDismiss = { activeSavedDetailPlace = null }
        )
    }

    // --- DIALOG OVERLAYS FOR THE HOME SCREEN AI COMPANION SUITE ---
    val targetPlaceCacheFile = File(context.cacheDir, "chosen_assessment.png")
    val hasCacheChosen = targetPlaceCacheFile.exists()

    val selectedLandmarkForDialog = nearbyLandmarks.firstOrNull()?.first ?: LandmarksRegistry.pakistaniLandmarks.firstOrNull { 
        it.cityEn.lowercase().contains(mockCity.lowercase()) 
    } ?: LandmarksRegistry.pakistaniLandmarks.first()

    val currentSiteName = selectedLandmarkForDialog.nameEn
    val currentSiteUr = selectedLandmarkForDialog.nameUr
    val currentSiteEra = "Mughal Era"
    val currentSiteCity = selectedLandmarkForDialog.cityEn

    if (showMonumentChat) {
        MonumentChatDialog(
            monumentName = if (isUrdu) currentSiteUr else currentSiteName,
            era = currentSiteEra,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showMonumentChat = false }
        )
    }

    if (showScriptDecipher) {
        InscriptionDecipherDialog(
            bitmapPath = if (hasCacheChosen) targetPlaceCacheFile.absolutePath else null,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { 
                showScriptDecipher = false
                try { targetPlaceCacheFile.delete() } catch(e: Exception){}
            }
        )
    }

    if (showQuestMaster) {
        HeritageQuestDialog(
            city = currentSiteCity,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showQuestMaster = false }
        )
    }

    if (showConservation) {
        ConservationAnalyticsDialog(
            bitmapPath = if (hasCacheChosen) targetPlaceCacheFile.absolutePath else null,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { 
                showConservation = false
                try { targetPlaceCacheFile.delete() } catch(e: Exception){}
            }
        )
    }

    if (showDiscoveryCard) {
        DiscoveryCardDisplayDialog(
            siteName = currentSiteName,
            era = currentSiteEra,
            city = currentSiteCity,
            userName = if (isUrdu) "سیاح" else "Explorer",
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showDiscoveryCard = false }
        )
    }
}

// Helper translations for Mock Cities
fun translateCity(city: String): String {
    return when (city) {
        "Lahore" -> "لاہور"
        "Karachi" -> "کراچی"
        "Islamabad" -> "اسلام آباد"
        "Peshawar" -> "پشاور"
        "Quetta" -> "کوئٹہ"
        else -> city
    }
}

@Composable
fun imageOfMonumentIcon() = Icons.Default.Museum

// --- CAMERAX SCANNERS VIEW SCREEN ---

@Composable
fun CameraScreen(
    navController: NavController,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val lensFacing = CameraSelector.LENS_FACING_BACK
    
    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    val imageCapture: ImageCapture = remember { ImageCapture.Builder().build() }
    
    var isUploading by remember { mutableStateOf(false) }

    // Launcher for standard device Gallery photo picker
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null && !isUploading) {
            isUploading = true
            val bitmap = handleSelectedUri(context, uri)
            if (bitmap != null) {
                viewModel.performAiAnalysis(context, bitmap)
                navController.navigate("result")
            } else {
                Toast.makeText(context, "Error uploading photo", Toast.LENGTH_SHORT).show()
                isUploading = false
            }
        }
    }

    // Camera permission checker fallback
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(context, "Camera permission required. You can upload from your gallery instead.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // CameraX Viewfinder Layout
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = androidx.camera.core.Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            context as androidx.lifecycle.LifecycleOwner,
                            CameraSelector.Builder().requireLensFacing(lensFacing).build(),
                            preview,
                            imageCapture
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, androidx.core.content.ContextCompat.getMainExecutor(ctx))
                
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Camera grid scan lines Overlay representation
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(BorderStroke(2.dp, Color.White.copy(alpha = 0.15f)))
        ) {
            // Overlay Scan frame guides
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.Center)
                    .border(BorderStroke(3.dp, ShahiGold), shape = RoundedCornerShape(24.dp))
                    .background(Color.Black.copy(alpha = 0.1f))
            )
            
            Text(
                text = "Point camera at any monument architecture\nکسی بھی تاریخی عمارت پر کیمرہ فوکس کریں",
                color = Color.White,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                lineHeight = 15.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 175.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        // Action Toolbar Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
                .padding(horizontal = 24.dp, vertical = 40.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Close / Go Back Button
            IconButton(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            // Central Capture Shutter
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .border(BorderStroke(4.dp, Color.White), CircleShape)
                    .background(Color.Transparent)
                    .clickable {
                        if (!isUploading) {
                            isUploading = true
                            // Save captured snapshot
                            val photoFile = File(context.cacheDir, "khoj_capture_${System.currentTimeMillis()}.jpg")
                            val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

                            imageCapture.takePicture(
                                outputOptions,
                                cameraExecutor,
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        val bitmap = try {
                                            if (photoFile.exists()) {
                                                val bytes = photoFile.readBytes()
                                                if (bytes.isNotEmpty()) {
                                                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                                                    
                                                    val maxDim = 1024
                                                    var scale = 1
                                                    if (options.outWidth > maxDim || options.outHeight > maxDim) {
                                                        val widthScale = options.outWidth / maxDim
                                                        val heightScale = options.outHeight / maxDim
                                                        scale = Math.max(widthScale, heightScale)
                                                    }
                                                    
                                                    val decodeOptions = BitmapFactory.Options().apply {
                                                        inSampleSize = if (scale > 1) scale else 1
                                                        inPreferredConfig = Bitmap.Config.ARGB_8888
                                                    }
                                                    var decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)
                                                    
                                                    if (decoded != null) {
                                                        try {
                                                            java.io.ByteArrayInputStream(bytes).use { bais ->
                                                                val exif = ExifInterface(bais)
                                                                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                                                                val matrix = Matrix()
                                                                when (orientation) {
                                                                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                                                                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                                                                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                                                                }
                                                                if (orientation == ExifInterface.ORIENTATION_ROTATE_90 || 
                                                                    orientation == ExifInterface.ORIENTATION_ROTATE_180 || 
                                                                    orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                                                                    val rotatedBitmap = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                                                                    if (rotatedBitmap != decoded) {
                                                                        decoded.recycle()
                                                                    }
                                                                    decoded = rotatedBitmap
                                                                }
                                                            }
                                                        } catch (ex: Exception) {
                                                            android.util.Log.e("Screens", "In-memory EXIF rotation failed", ex)
                                                        }
                                                    }
                                                    decoded
                                                } else {
                                                    null
                                                }
                                            } else {
                                                null
                                            }
                                        } catch (e: Exception) {
                                            android.util.Log.e("Screens", "Error reading/decoding captured bytes", e)
                                            null
                                        } finally {
                                            try {
                                                if (photoFile.exists()) {
                                                    photoFile.delete()
                                                }
                                            } catch (ex: Exception) {
                                                android.util.Log.e("Screens", "Failed to clean cache file", ex)
                                            }
                                        }

                                        if (bitmap != null) {
                                            viewModel.performAiAnalysis(context, bitmap)
                                            // Update navigation state on Main thread
                                            androidx.core.content.ContextCompat.getMainExecutor(context).execute {
                                                navController.navigate("result")
                                            }
                                        } else {
                                            isUploading = false
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        exception.printStackTrace()
                                        isUploading = false
                                    }
                                }
                            )
                        }
                    }
                    .padding(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(ShahiGold)
                )
            }

            // Pick Image from Gallery
            IconButton(
                onClick = { galleryLauncher.launch("image/*") },
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = "Pick Image", tint = Color.White)
            }
        }
    }
}

// Utility to read gallery/capturedUri and decrypt into a safe, correctly rotated and scaled Bitmap
private fun handleSelectedUri(context: Context, uri: Uri): Bitmap? {
    return try {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BitmapFactory.decodeStream(inputStream, null, options)
        }

        val maxDim = 1024
        var scale = 1
        if (options.outWidth > maxDim || options.outHeight > maxDim) {
            val widthScale = options.outWidth / maxDim
            val heightScale = options.outHeight / maxDim
            scale = Math.max(widthScale, heightScale)
        }

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = if (scale > 1) scale else 1
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bitmap = context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BitmapFactory.decodeStream(inputStream, null, decodeOptions)
        }

        if (bitmap != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { exifStream ->
                    val exif = ExifInterface(exifStream)
                    val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                    val matrix = Matrix()
                    when (orientation) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    }
                    if (orientation == ExifInterface.ORIENTATION_ROTATE_90 || 
                        orientation == ExifInterface.ORIENTATION_ROTATE_180 || 
                        orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                        val rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                        if (rotatedBitmap != bitmap) {
                            bitmap.recycle()
                        }
                        bitmap = rotatedBitmap
                    }
                }
            } catch (ex: Exception) {
                android.util.Log.e("Screens", "Exif rotation correction from uri failed", ex)
            }
        }
        bitmap
    } catch (e: Exception) {
        android.util.Log.e("Screens", "Error handleSelectedUri", e)
        null
    }
}

// Utility to read a captured camera photo file, correct rotation and scale to memory safe bounds
private fun handleCapturedFile(context: Context, photoPath: String): Bitmap? {
    return try {
        val file = File(photoPath)
        if (!file.exists() || file.length() == 0L) {
            android.util.Log.e("Screens", "Captured file does not exist or is empty: $photoPath")
            return null
        }
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        java.io.FileInputStream(file).use { fis ->
            BitmapFactory.decodeStream(fis, null, options)
        }

        val maxDim = 1024
        var scale = 1
        if (options.outWidth > maxDim || options.outHeight > maxDim) {
            val widthScale = options.outWidth / maxDim
            val heightScale = options.outHeight / maxDim
            scale = Math.max(widthScale, heightScale)
        }

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = if (scale > 1) scale else 1
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bitmap = java.io.FileInputStream(file).use { fis ->
            BitmapFactory.decodeStream(fis, null, decodeOptions)
        }

        if (bitmap != null) {
            try {
                val exif = ExifInterface(photoPath)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                }
                if (orientation == ExifInterface.ORIENTATION_ROTATE_90 || 
                    orientation == ExifInterface.ORIENTATION_ROTATE_180 || 
                    orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                    val rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    if (rotatedBitmap != bitmap) {
                        bitmap.recycle()
                    }
                    bitmap = rotatedBitmap
                }
            } catch (ex: Exception) {
                android.util.Log.e("Screens", "Exif rotation correction failed", ex)
            }
        }
        bitmap
    } catch (e: Exception) {
        android.util.Log.e("Screens", "Error handleCapturedFile", e)
        null
    }
}

// --- ANALYSIS DISPLAY & AUDIO DECODER SCREEN ---

@Composable
fun ResultScreen(
    navController: NavController,
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scanState by viewModel.scanState.collectAsState()
    val isUrdu by viewModel.isUrduMode.collectAsState()
    
    val coroutineScope = rememberCoroutineScope()
    
    var showMonumentChat by remember { mutableStateOf(false) }
    var showScriptDecipher by remember { mutableStateOf(false) }
    var showQuestMaster by remember { mutableStateOf(false) }
    var showConservation by remember { mutableStateOf(false) }
    var showDiscoveryCard by remember { mutableStateOf(false) }

    // Initialize speech narrator
    val speechManager = remember { SpeechManager(context) }
    
    DisposableEffect(Unit) {
        onDispose {
            speechManager.shutdown()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        when (val state = scanState) {
            is ScanState.Scanning -> {
                // Customized historical analysis spinner card
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        color = ShahiGold,
                        modifier = Modifier.size(60.dp),
                        strokeWidth = 6.dp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = if (isUrdu) "تاریخ کی تلاش جاری ہے..." else "Discovering History...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isUrdu) "خوج اسمارٹ امیج پروسیسنگ اور آرٹیفیشل انٹیلیجنس کے ذریعے اس عمارت کا طرز تعمیر اور پس منظر جاننے کی کوشش کر رہا ہے۔" 
                               else "KHOJ intelligence is analyzing architectural characteristics and matching records...",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 14.dp)
                    )
                }
            }

            is ScanState.Error -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    val isRateLimit = state.message.contains("high traffic", ignoreCase = true) || state.message.contains("429", ignoreCase = true)
                    Text(
                        text = if (isRateLimit) {
                            if (isUrdu) "سرور مصروف ہے" else "Server Busy"
                        } else {
                            if (isUrdu) "رابطے میں رکاوٹ" else "Analysis Interrupted"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isRateLimit && isUrdu) {
                            "سرور پر لوڈ زیادہ ہے۔ براہ کرم کچھ دیر بعد دوبارہ کوشش کریں۔"
                        } else {
                            state.message
                        },
                        fontSize = 13.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            viewModel.resetState()
                            navController.popBackStack()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(text = if (isUrdu) "پیچھے جائیں" else "Back to Explorer")
                    }
                }
            }

            is ScanState.Success -> {
                val details = state.details
                
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Top Hero capture preview
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                        ) {
                            if (state.localImagePath != null) {
                                AsyncImage(
                                    model = File(state.localImagePath),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(EmeraldGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Museum, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(56.dp))
                                }
                            }
                            
                            // Close/Back overlay button
                            IconButton(
                                onClick = {
                                    speechManager.stop()
                                    viewModel.resetState()
                                    navController.popBackStack()
                                },
                                modifier = Modifier
                                    .padding(top = 40.dp, start = 16.dp)
                                    .align(Alignment.TopStart)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                        }
                    }

                    // Content panel
                    item {
                        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                            Text(
                                text = if (isUrdu) details.nameUr else details.nameEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 26.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (isUrdu) details.eraUr else details.eraEn,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = ShahiGold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            
                            Spacer(modifier = Modifier.height(14.dp))
                            
                            // Narrator / Speech control cards
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.VolumeUp,
                                        contentDescription = "Audio Guide",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isUrdu) "آڈیو گائیڈNarrator " else "Interactive Audio Narrator",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = if (isUrdu) "مضمون خودکار طریقے سے سننے کے لئے زبان کا انتخاب کریں۔" else "Choose language pack to hear the narration offline:",
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    // Play in English
                                    Button(
                                        onClick = { speechManager.speak(details.historyEn, false) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                        modifier = Modifier.height(32.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("English Guide", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Play in Urdu
                                    Button(
                                        onClick = { speechManager.speak(details.historyUr, true) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                        modifier = Modifier.height(32.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Black)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("اردو آواز", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }

                                    // Stop Voice button
                                    IconButton(
                                        onClick = { speechManager.stop() },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Stop, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }

                    // Story Background Card
                    item {
                        InfoSectionCard(
                            isUrdu = isUrdu,
                            titleEn = "The Story & Foundations",
                            titleUr = "تاریخ اور پس منظر",
                            textEn = details.historyEn,
                            textUr = details.historyUr,
                            icon = Icons.Default.MenuBook
                        )
                    }

                    // Peak Glory Visual Description Card
                    item {
                        InfoSectionCard(
                            isUrdu = isUrdu,
                            titleEn = "At Its Peak Glory",
                            titleUr = "عروج کا دور",
                            textEn = details.peakEn,
                            textUr = details.peakUr,
                            icon = Icons.Default.AutoAwesome
                        )
                    }

                    // Hidden Connection Card
                    item {
                        InfoSectionCard(
                            isUrdu = isUrdu,
                            titleEn = "Hidden Connections & Secrets",
                            titleUr = "پوشیدہ راز اور کہانیاں",
                            textEn = details.connectionEn,
                            textUr = details.connectionUr,
                            icon = Icons.Default.HelpCenter
                        )
                    }

                    // Elegant Interactive AI Companion Suite Card
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.5.dp, ShahiGold.copy(alpha = 0.6f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = ShahiGold,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isUrdu) "اے آئی ورثہ معاونین" else "AI Heritage Companion Suite",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isUrdu) 
                                        "تاریخی عمارت سے بات چیت، قدیم نقوش کا ترجمہ، ورثہ سیاحت پلاننگ اور مزید اے آئی فیچرز منتخب کریں۔" 
                                        else "Interact with the monument, decode ancient scripts, generate custom tours, or analyze conservation health with AI.",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                                
                                Spacer(modifier = Modifier.height(14.dp))
                                
                                val landmarkCity = details.city
                                val landmarkName = details.nameEn
                                val landmarkEra = details.eraEn

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Row 1: Chat with Monument (Full Width)
                                    Button(
                                        onClick = { showMonumentChat = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isUrdu) "عمارت سے گفتگو" else "Chat to Site", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Row 2: Weekly Quest
                                    Button(
                                        onClick = { showQuestMaster = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isUrdu) "ہفتہ وار چیلنج" else "Weekly Quest", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Row 3: Conservation Check & Discovery Card
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { showConservation = true },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(if (isUrdu) "حفاظتی جائزہ" else "Heritage Health", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Button(
                                            onClick = { showDiscoveryCard = true },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.IosShare, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(if (isUrdu) "شوسل کارڈ" else "Discovery Card", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Suggested Nearby Locations section inside Scan Result
                    item {
                        val nearbyLandmarks by viewModel.nearbyLandmarks.collectAsState()
                        if (nearbyLandmarks.isNotEmpty()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isUrdu) "آس پاس گھومنے کی جگہیں" else "Nearby Historical Sites to Visit",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (isUrdu) "موجودہ پوزیشن سے فاصلہ اور سفر کا وقت۔ نقشہ کھولنے کے لیے انتخاب کریں۔" else "Distance and travel time from you. Click to navigate.",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                                
                                nearbyLandmarks.take(3).forEach { (landmark, distance) ->
                                    val context = LocalContext.current
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable {
                                                val uri = Uri.parse("geo:0,0?q=${landmark.latitude},${landmark.longitude}(${Uri.encode(landmark.nameEn)})")
                                                val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                                                try {
                                                    context.startActivity(mapIntent)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "Could not launch Maps", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.Place,
                                                contentDescription = null,
                                                tint = ShahiGold,
                                                modifier = Modifier.size(24.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (isUrdu) landmark.nameUr else landmark.nameEn,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Text(
                                                    text = if (isUrdu) "${"%.1f".format(distance)} کلومیٹر دور (نقشہ دکھانے کے لئے دبائیں)" else "${"%.1f".format(distance)} km away (Tap to Navigate)",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = ShahiGold
                                                )
                                            }
                                            Icon(
                                                Icons.Default.Navigation,
                                                contentDescription = "Navigate",
                                                tint = MaterialTheme.colorScheme.secondary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Back Explorer action button helper
                    item {
                        Button(
                            onClick = {
                                speechManager.stop()
                                viewModel.resetState()
                                navController.popBackStack()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(
                                text = if (isUrdu) "📸 اسکین کیمرہ دوبارہ کھولیں" else "📸 Return to Explorer",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                    }
                }
            }
            
            else -> {
                Box(modifier = Modifier.fillMaxSize())
            }
        }

        if (scanState is ScanState.Success) {
            val details = (scanState as ScanState.Success).details
            val landmarkCitySafe = if (details.nameEn.lowercase().contains("shahi qila") || details.nameEn.lowercase().contains("badshahi") || details.nameEn.lowercase().contains("lahore") || details.nameEn.lowercase().contains("shalimar")) "Lahore"
                else if (details.nameEn.lowercase().contains("faisal mosque") || details.nameEn.lowercase().contains("islamabad")) "Islamabad"
                else if (details.nameEn.lowercase().contains("mohenjo") || details.nameEn.lowercase().contains("larkana")) "Larkana"
                else if (details.nameEn.lowercase().contains("makli") || details.nameEn.lowercase().contains("thetta")) "Thatta"
                else "Lahore"

            if (showMonumentChat) {
                MonumentChatDialog(
                    monumentName = if (isUrdu) details.nameUr else details.nameEn,
                    era = if (isUrdu) details.eraUr else details.eraEn,
                    isUrdu = isUrdu,
                    viewModel = viewModel,
                    onDismiss = { showMonumentChat = false }
                )
            }

            if (showScriptDecipher) {
                InscriptionDecipherDialog(
                    bitmapPath = (scanState as ScanState.Success).localImagePath,
                    isUrdu = isUrdu,
                    viewModel = viewModel,
                    onDismiss = { showScriptDecipher = false }
                )
            }

            if (showQuestMaster) {
                HeritageQuestDialog(
                    city = landmarkCitySafe,
                    isUrdu = isUrdu,
                    viewModel = viewModel,
                    onDismiss = { showQuestMaster = false }
                )
            }

            if (showConservation) {
                ConservationAnalyticsDialog(
                    bitmapPath = (scanState as ScanState.Success).localImagePath,
                    isUrdu = isUrdu,
                    viewModel = viewModel,
                    onDismiss = { showConservation = false }
                )
            }

            if (showDiscoveryCard) {
                DiscoveryCardDisplayDialog(
                    siteName = details.nameEn,
                    era = details.eraEn,
                    city = if (details.nameEn.lowercase().contains("shahi qila") || details.nameEn.lowercase().contains("badshahi") || details.nameEn.lowercase().contains("lahore") || details.nameEn.lowercase().contains("shalimar")) "Lahore, Pakistan"
                        else if (details.nameEn.lowercase().contains("faisal mosque") || details.nameEn.lowercase().contains("islamabad")) "Islamabad, Pakistan"
                        else if (details.nameEn.lowercase().contains("mohenjo") || details.nameEn.lowercase().contains("larkana")) "Mohenjo-daro, Sindh, Pakistan"
                        else if (details.nameEn.lowercase().contains("makli") || details.nameEn.lowercase().contains("thetta")) "Thatta, Sindh, Pakistan"
                        else "Lahore, Pakistan",
                    userName = if (isUrdu) "سیاح" else "Explorer",
                    isUrdu = isUrdu,
                    viewModel = viewModel,
                    onDismiss = { showDiscoveryCard = false }
                )
            }
        }
    }
}

// --- REUSABLE CARD WRAPPER FOR NARRATIVES ---

@Composable
fun InfoSectionCard(
    isUrdu: Boolean,
    titleEn: String,
    titleUr: String,
    textEn: String,
    textUr: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isUrdu) titleUr else titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (isUrdu) textUr else textEn,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = TextPrimary,
                textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left
            )
        }
    }
}

// --- LANDMARK EXPLANATION DIALOG WIDGET ---

@Composable
fun LandmarkDetailDialog(
    landmark: HistoricalLandmark,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Mosque, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) landmark.nameUr else landmark.nameEn,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${if (isUrdu) "مقام" else "Province"}: ${if (isUrdu) landmark.cityUr else landmark.cityEn}",
                    fontSize = 11.sp,
                    color = ShahiGold,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.primaryContainer)
                Spacer(modifier = Modifier.height(14.dp))
                
                Text(
                    text = if (isUrdu) landmark.descriptionUr else landmark.descriptionEn,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = TextPrimary,
                    textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left
                )
                
                Spacer(modifier = Modifier.height(18.dp))
                
                val context = LocalContext.current
                Button(
                    onClick = {
                        val uriStr = "geo:0,0?q=${landmark.latitude},${landmark.longitude}(${landmark.nameEn})"
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uriStr))
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open Google Maps", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "گوگل میپس پر راستہ تلاش کریں" else "Navigate using Google Maps",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                Button(
                    onClick = {
                        viewModel.exploreToday(landmark.nameEn)
                        Toast.makeText(context, if (isUrdu) "ورثہ کی کارکردگی اور آج کا دن ریکارڈ کر لیا گیا ہے! 🌟" else "Logged exploration & updated weekly streak! 🌟", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "میں نے یہ مقام گھوم لیا ہے!" else "I Explored / Visited This Place!",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(text = if (isUrdu) "بند کریں" else "Cool")
                }
            }
        }
    }
}

// --- SAVED EXPLORED PLACE DETAILS FULL DIALOG REPORT ---

@Composable
fun SavedPlaceReportDialog(
    place: ExploredPlace,
    viewModel: MainViewModel,
    isUrdu: Boolean,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    
    var showMonumentChat by remember { mutableStateOf(false) }
    var showScriptDecipher by remember { mutableStateOf(false) }
    var showQuestMaster by remember { mutableStateOf(false) }
    var showConservation by remember { mutableStateOf(false) }
    var showDiscoveryCard by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isUrdu) place.nameUr else place.nameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Text(
                        text = if (isUrdu) place.eraUr else place.eraEn,
                        fontSize = 13.sp,
                        color = ShahiGold,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                item {
                    HorizontalDivider(color = MaterialTheme.colorScheme.primaryContainer)
                }

                // Image captured preview
                place.imagePath?.let { path ->
                    val file = File(path)
                    if (file.exists()) {
                        item {
                            AsyncImage(
                                model = file,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = if (isUrdu) "تاریخی تفصیل" else "Historical Narrative",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isUrdu) place.historyUr else place.historyEn,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                item {
                    Text(
                        text = if (isUrdu) "عروج کا دور" else "At Its Peak",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isUrdu) place.peakUr else place.peakEn,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                item {
                    Text(
                        text = if (isUrdu) "پوشیدہ حقائق" else "Connected Secrets",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (isUrdu) place.connectionUr else place.connectionEn,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                place.note?.let { note ->
                    if (note.isNotBlank()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (isUrdu) "میرا سفرنامہ نوٹ" else "My Personal Note",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = note,
                                        fontSize = 12.sp,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                // Elegant Interactive AI Companion Suite Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, ShahiGold.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = ShahiGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isUrdu) "اے آئی ورثہ معاونین" else "AI Heritage Companion Suite",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isUrdu) 
                                    "تاریخی عمارت سے بات چیت، قدیم نقوش کا ترجمہ، ورثہ سیاحت پلاننگ اور مزید اے آئی فیچرز منتخب کریں۔" 
                                    else "Interact with the monument, decode ancient scripts, generate custom tours, or analyze conservation health with AI.",
                                fontSize = 11.sp,
                                color = TextSecondary
                             )
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            val landmarkCitySafe = if (place.nameEn.lowercase().contains("shahi qila") || place.nameEn.lowercase().contains("badshahi") || place.nameEn.lowercase().contains("lahore") || place.nameEn.lowercase().contains("shalimar")) "Lahore"
                                else if (place.nameEn.lowercase().contains("faisal mosque") || place.nameEn.lowercase().contains("islamabad")) "Islamabad"
                                else if (place.nameEn.lowercase().contains("mohenjo") || place.nameEn.lowercase().contains("larkana")) "Larkana"
                                else if (place.nameEn.lowercase().contains("makli") || place.nameEn.lowercase().contains("thetta")) "Thatta"
                                else "Lahore"

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Row 1: Chat with Monument (Full Width)
                                Button(
                                    onClick = { showMonumentChat = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Chat, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isUrdu) "عمارت سے گفتگو" else "Chat to Site", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // Row 2: Weekly Quest
                                Button(
                                    onClick = { showQuestMaster = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isUrdu) "ہفتہ وار چیلنج" else "Weekly Quest", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // Row 3: Conservation Check & Discovery Card
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { showConservation = true },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isUrdu) "حفاظتی جائزہ" else "Heritage Health", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Button(
                                        onClick = { showDiscoveryCard = true },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.IosShare, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isUrdu) "شوسل کارڈ" else "Discovery Card", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.align(Alignment.CenterEnd),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(text = if (isUrdu) "بند کریں" else "Close Report")
                        }
                    }
                }
            }
        }
    }

    val showMonumentChatLocal = showMonumentChat
    val showScriptDecipherLocal = showScriptDecipher
    val showQuestMasterLocal = showQuestMaster
    val showConservationLocal = showConservation
    val showDiscoveryCardLocal = showDiscoveryCard

    if (showMonumentChatLocal) {
        MonumentChatDialog(
            monumentName = if (isUrdu) place.nameUr else place.nameEn,
            era = if (isUrdu) place.eraUr else place.eraEn,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showMonumentChat = false }
        )
    }

    if (showScriptDecipherLocal) {
        InscriptionDecipherDialog(
            bitmapPath = place.imagePath,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showScriptDecipher = false }
        )
    }

    if (showQuestMasterLocal) {
        val targetCityAddressSafe = if (place.nameEn.lowercase().contains("shahi qila") || place.nameEn.lowercase().contains("badshahi") || place.nameEn.lowercase().contains("lahore") || place.nameEn.lowercase().contains("shalimar")) "Lahore"
            else if (place.nameEn.lowercase().contains("faisal mosque") || place.nameEn.lowercase().contains("islamabad")) "Islamabad"
            else if (place.nameEn.lowercase().contains("mohenjo") || place.nameEn.lowercase().contains("larkana")) "Larkana"
            else if (place.nameEn.lowercase().contains("makli") || place.nameEn.lowercase().contains("thetta")) "Thatta"
            else "Lahore"

        HeritageQuestDialog(
            city = targetCityAddressSafe,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showQuestMaster = false }
        )
    }

    if (showConservationLocal) {
        ConservationAnalyticsDialog(
            bitmapPath = place.imagePath,
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showConservation = false }
        )
    }

    if (showDiscoveryCardLocal) {
        DiscoveryCardDisplayDialog(
            siteName = place.nameEn,
            era = place.eraEn,
            city = if (place.nameEn.lowercase().contains("shahi qila") || place.nameEn.lowercase().contains("badshahi") || place.nameEn.lowercase().contains("lahore") || place.nameEn.lowercase().contains("shalimar")) "Lahore, Pakistan"
                else if (place.nameEn.lowercase().contains("faisal mosque") || place.nameEn.lowercase().contains("islamabad")) "Islamabad, Pakistan"
                else if (place.nameEn.lowercase().contains("mohenjo") || place.nameEn.lowercase().contains("larkana")) "Mohenjo-daro, Sindh, Pakistan"
                else if (place.nameEn.lowercase().contains("makli") || place.nameEn.lowercase().contains("thetta")) "Thatta, Sindh, Pakistan"
                else "Lahore, Pakistan",
            userName = if (isUrdu) "سیاح" else "Explorer",
            isUrdu = isUrdu,
            viewModel = viewModel,
            onDismiss = { showDiscoveryCard = false }
        )
    }
}

// --- ADD NOTE WIDGET DIALOG ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditNotesDialog(
    place: ExploredPlace,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var noteText by remember { mutableStateOf(place.note ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Add Notes / یادداشت درج کریں",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Write your thoughts or checklist for ${place.nameEn}:",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    maxLines = 4,
                    placeholder = { Text("e.g. Visited this place on Sunday evening with family. / اتوار کو ہم یہاں گھومنے آئے۔...") }
                )

                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            viewModel.addNoteToExploredItem(place, noteText)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Save Note")
                    }
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 1: MONUMENT CHAT ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonumentChatDialog(
    monumentName: String,
    era: String,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isSending by viewModel.isSendingChatMessage.collectAsState()
    var textInput by remember { mutableStateOf("") }

    LaunchedEffect(monumentName) {
        val opener = if (isUrdu) {
            "خوش آمدید، معزز سیاح! میں نے صدیوں کی دھوپ، ہوا اور بارشیں دیکھی ہیں۔ میں $monumentName ہوں، جو $era میں تعمیر کی گئی تھی۔ مجھ سے کوئی بھی تاریخی سوال پوچھیں..."
        } else {
            "Welcome, humble traveler! I am $monumentName, whose stones were laid in $era. Ask me anything about my history or builders, and my ancient stones shall answer..."
        }
        viewModel.resetChat(opener)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Chat, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isUrdu) "عمارت سے مکالمہ" else "Chat to Site",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = monumentName,
                            fontSize = 11.sp,
                            color = ShahiGold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { message ->
                        val isUser = message.second
                        val content = message.first
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 14.dp,
                                    topEnd = 14.dp,
                                    bottomStart = if (isUser) 14.dp else 2.dp,
                                    bottomEnd = if (isUser) 2.dp else 14.dp
                                ),
                                color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer,
                                contentColor = if (isUser) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.widthIn(max = 240.dp)
                            ) {
                                Text(
                                    text = content,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(10.dp),
                                    lineHeight = 17.sp
                                )
                            }
                        }
                    }

                    if (isSending) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = ShahiGold, strokeWidth = 1.5.dp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (isUrdu) "قدیم یادوں سے جواب تلاش کیا جا رہا ہے..." else "Recalling historical chronicles...",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text(if (isUrdu) "انگریزی یا اردو میں سوال لکھیں..." else "Ask Monument in English or Urdu...", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendChatMessage(monumentName, era, textInput)
                                textInput = ""
                            }
                        },
                        enabled = !isSending && textInput.isNotBlank(),
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (textInput.isNotBlank() && !isSending) ShahiGold else Color.Gray.copy(alpha = 0.3f))
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (textInput.isNotBlank() && !isSending) Color.Black else Color.White
                        )
                    }
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 2: SCRIPT DECIPHER ---

@Composable
fun InscriptionDecipherDialog(
    bitmapPath: String?,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val scriptState by viewModel.scriptState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(bitmapPath) {
        if (bitmapPath != null) {
            val file = File(bitmapPath)
            if (file.exists()) {
                val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                if (bitmap != null) {
                    viewModel.decipherInscription(bitmap)
                } else {
                    viewModel.resetScriptState()
                }
            }
        } else {
            val mockBitmap = BitmapFactory.decodeResource(context.resources, android.R.drawable.ic_menu_gallery)
            if (mockBitmap != null) {
                viewModel.decipherInscription(mockBitmap)
            }
        }
    }

    Dialog(onDismissRequest = {
        viewModel.resetScriptState()
        onDismiss()
    }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Translate, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "قدیم رسم الخط کا ترجمہ" else "Ancient Script Assessment",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (val state = scriptState) {
                        is ScriptState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(if (isUrdu) "رسم الخط کی تصویر لوڈ کی جا رہی ہے..." else "Loading script camera frame...", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                        is ScriptState.Deciphering -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ShahiGold)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (isUrdu) "اے آئی کی طرف سے قدیم زبان اور نقوش کا تجزیہ کیا جا رہا ہے..." else "Analyzing ancient inscriptions & script characters with AI...",
                                    fontSize = 12.sp,
                                    color = ShahiGold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                        is ScriptState.Success -> {
                            val res = state.result
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = ShahiGold.copy(alpha = 0.15f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp).fillMaxWidth()) {
                                            Text(
                                                text = if (isUrdu) "رسم الخط کی قسم" else "Detected Script Type",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = ShahiGold
                                            )
                                            Text(
                                                text = "${res.scriptType} (${res.language})",
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "${if (isUrdu) "اندازہ لگانے کا دور" else "Estimated Era"}: ${res.approximatePeriod}",
                                                fontSize = 11.sp,
                                                color = TextPrimary
                                            )
                                        }
                                    }
                                }

                                item {
                                    Column {
                                        Text(if (isUrdu) "نقل حرفی (Transcription)" else "Transliteration", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Surface(
                                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(res.transcription, modifier = Modifier.padding(10.dp), fontStyle = FontStyle.Italic, fontSize = 12.sp)
                                        }
                                    }
                                }

                                item {
                                    Column {
                                        Text(if (isUrdu) "مفہوم و ترجمہ (Translation)" else "Translation", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Surface(
                                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(res.translation, modifier = Modifier.padding(10.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }

                                item {
                                    Column {
                                        Text(if (isUrdu) "تاریخی افادیت و اہمیت" else "Historical Significance & Context", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Text(res.significance, modifier = Modifier.padding(top = 4.dp), fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                                    }
                                }

                                if (!res.confidenceNote.isNullOrBlank()) {
                                    item {
                                        Text(
                                            text = "Note: ${res.confidenceNote}",
                                            fontSize = 9.sp,
                                            color = TextSecondary,
                                            fontStyle = FontStyle.Italic
                                        )
                                    }
                                }
                            }
                        }
                        is ScriptState.Error -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(state.message, color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (isUrdu) "مکمل" else "Completed")
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 3: HERITAGE TRAIL ---

@Composable
fun HeritageTrailDialog(
    city: String,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val trailState by viewModel.trailState.collectAsState()
    var selectedHours by remember { mutableStateOf(4) }

    LaunchedEffect(city, selectedHours) {
        viewModel.curateTrail(city, selectedHours)
    }

    Dialog(onDismissRequest = {
        viewModel.resetTrailState()
        onDismiss()
    }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "حسب ضرورت تاریخی راستہ" else "Custom Heritage Trail",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (isUrdu) "وقت منتخب کریں:" else "Time Available:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    listOf(4, 8, 24).forEach { hr ->
                        val isSel = selectedHours == hr
                        Surface(
                            onClick = { selectedHours = hr },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) ShahiGold else MaterialTheme.colorScheme.primaryContainer,
                            contentColor = if (isSel) Color.Black else MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        ) {
                            Text(
                                text = "$hr hr",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (val state = trailState) {
                        is TrailState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(if (isUrdu) "راستہ منتخب کیا جا رہا ہے..." else "Preparing your journey options...", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                        is TrailState.Curating -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ShahiGold)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (isUrdu) "اے آئی آپ کے لیے بہترین تاریخی راستہ بنا رہا ہے..." else "Curating landmarks, spacing trails, & tasting local stops...",
                                    fontSize = 12.sp,
                                    color = ShahiGold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                        is TrailState.Success -> {
                            val trail = state.trail
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp).fillMaxWidth()) {
                                            Text(trail.trailName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Difficulty: ${trail.difficulty} • Total: ${trail.totalDistance} (Est. ${trail.totalDuration})",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = ShahiGold
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(trail.trailStory, fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                                        }
                                    }
                                }

                                item {
                                    Text(if (isUrdu) "تفصیلی پڑاؤ اور منزلیں" else "Curated Stopovers:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                }

                                items(trail.sites) { site ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = ShahiGold,
                                            contentColor = Color.Black,
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(site.order.toString(), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(site.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                                            Text("Duration: ${site.timeToSpend} | ${site.distanceFromPrevious} via ${site.travelMode}", fontSize = 10.sp, color = TextSecondary)
                                            Text("${if (isUrdu) "خاص بات" else "Highlight"}: ${site.highlight}", fontSize = 11.sp, color = TextPrimary, modifier = Modifier.padding(top = 2.dp))
                                            Text("📸 Best Spot: ${site.bestPhotoSpot}", fontSize = 10.sp, fontStyle = FontStyle.Italic, color = ShahiGold, modifier = Modifier.padding(top = 1.dp))
                                        }
                                    }
                                }

                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = ShahiGold.copy(alpha = 0.12f)),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Restaurant, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(
                                                    text = "Local Culinary Stop: ${trail.localFoodStop.name}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Text(
                                                    text = "Signature Dish: ${trail.localFoodStop.dish} - ${trail.localFoodStop.why}",
                                                    fontSize = 10.sp,
                                                    color = TextPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        is TrailState.Error -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(state.message, color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (isUrdu) "بند کریں" else "Done")
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 4: WEEKLY QUEST MASTER ---

@Composable
fun HeritageQuestDialog(
    city: String,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val questState by viewModel.questState.collectAsState()

    LaunchedEffect(city) {
        viewModel.generateQuest(city)
    }

    Dialog(onDismissRequest = {
        viewModel.resetQuestState()
        onDismiss()
    }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "ہفتہ وار ورثہ تلاش چیلنج" else "Weekly Heritage Quest",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (val state = questState) {
                        is QuestState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(if (isUrdu) "چیلنج لوڈ ہو رہا ہے..." else "Loading weekly heritage quest...", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                        is QuestState.Generating -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ShahiGold)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (isUrdu) "ورثہ ماسٹر سے ہفتہ وار خصوصی چیلنج بنوایا جا رہا ہے..." else "Formulating authentic historical challenges for $city...",
                                    fontSize = 12.sp,
                                    color = ShahiGold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                        is QuestState.Success -> {
                            val quest = state.quest
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp).fillMaxWidth()) {
                                            Text(quest.questTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text("Theme: ${quest.theme} | Time: ${quest.timeRequired}", fontSize = 11.sp, color = ShahiGold, fontWeight = FontWeight.Bold)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(quest.funHistoryHook, fontSize = 11.sp, fontStyle = FontStyle.Italic, color = TextPrimary)
                                        }
                                    }
                                }

                                item {
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Text(if (isUrdu) "چیلنج کے مقامات" else "Quest Heritage Sites to Scan:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        quest.sitesToVisit.forEachIndexed { idx, s ->
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(s, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                                            }
                                        }
                                    }
                                }

                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Verified, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(if (isUrdu) "بنیادی چیلنج" else "Main Objective", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(quest.mainChallenge, fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                                        }
                                    }
                                }

                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, ShahiGold.copy(alpha = 0.25f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Star, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(if (isUrdu) "اضافی چیلنج (بونس)" else "Bonus Quest Challenge", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = ShahiGold)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(quest.bonusChallenge, fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                                        }
                                    }
                                }

                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(22.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(if (isUrdu) "کامیابی کا نشان" else "Earn Award Badge:", fontSize = 10.sp, color = ShahiGold, fontWeight = FontWeight.Bold)
                                                Text(quest.rewardBadge, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        is QuestState.Error -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(state.message, color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                val state = questState
                if (state is QuestState.Success) {
                    Button(
                        onClick = {
                            viewModel.acceptQuest(state.quest)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(if (isUrdu) "چیلنج قبول کریں" else "Accept Quest Challenge")
                    }
                } else {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                    ) {
                        Text(if (isUrdu) "بند کریں" else "Dismiss")
                    }
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 5: CONSERVATION ANALYTICS ---

@Composable
fun ConservationAnalyticsDialog(
    bitmapPath: String?,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val conservationState by viewModel.conservationState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(bitmapPath) {
        if (bitmapPath != null) {
            val file = File(bitmapPath)
            if (file.exists()) {
                val bitmap = BitmapFactory.decodeFile(file.absolutePath)
                if (bitmap != null) {
                    viewModel.analyzeConservation(bitmap)
                } else {
                    viewModel.resetConservationState()
                }
            }
        } else {
            val mockBitmap = BitmapFactory.decodeResource(context.resources, android.R.drawable.ic_menu_gallery)
            if (mockBitmap != null) {
                viewModel.analyzeConservation(mockBitmap)
            }
        }
    }

    Dialog(onDismissRequest = {
        viewModel.resetConservationState()
        onDismiss()
    }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "ورثہ حفاظتی جائزہ" else "Heritage Conservation Health",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (val state = conservationState) {
                        is ConservationState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(if (isUrdu) "حفاظتی رپورٹ لوڈ کی جا رہی ہے..." else "Analyzing preservation report status...", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                        is ConservationState.Analyzing -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ShahiGold)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (isUrdu) "تصویر میں پتھروں، دراڑوں اور خطرات کا باریک بینی سے جائزہ لیا جا رہا ہے..." else "Analyzing material decay, crack lines, and structural preservation risks with AI...",
                                    fontSize = 12.sp,
                                    color = ShahiGold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                        is ConservationState.Success -> {
                            val report = state.report
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(if (isUrdu) "خطرے کا انڈیکس اسکور" else "Heritage Risk Score", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextSecondary)
                                            Text("${report.heritageAtRiskScore}/100", fontWeight = FontWeight.Bold, fontSize = 32.sp, color = ShahiGold)
                                            Text(
                                                text = "${if (isUrdu) "عمومی حالت" else "Overall Condition"}: ${report.overallCondition}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Preservation Urgency: ${report.preservationUrgency}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color.Red
                                            )
                                        }
                                    }
                                }

                                item {
                                    Text(if (isUrdu) "نقصانات کا مشاہدہ" else "Observed Material Risks:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                }

                                items(report.damageObserved) { damage ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp).fillMaxWidth()) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(if (damage.severity.lowercase().contains("high")) Color.Red else ShahiGold)
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(damage.severity, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(damage.type, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Spacer(modifier = Modifier.height(3.dp))
                                            Text("Area: ${damage.locationInImage}", fontSize = 10.sp, fontStyle = FontStyle.Italic, color = TextSecondary)
                                            Text(damage.description, fontSize = 11.sp, color = TextPrimary, modifier = Modifier.padding(top = 2.dp))
                                        }
                                    }
                                }

                                item {
                                    Column {
                                        Text(if (isUrdu) "تجویز کردہ بحالی اقدام" else "AI Recommended Action", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Text(report.recommendedAction, fontSize = 11.sp, color = TextPrimary, modifier = Modifier.padding(top = 2.dp), lineHeight = 16.sp)
                                    }
                                }

                                item {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = ShahiGold.copy(alpha = 0.1f)),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Yard, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(if (isUrdu) "مقامی سیاح کیا کر سکتے ہیں؟" else "How Visitors Can Support", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(report.whatVisitorCanDo, fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp)
                                        }
                                    }
                                }

                                item {
                                    Text(
                                        text = report.encouragingMessage,
                                        fontSize = 11.sp,
                                        fontStyle = FontStyle.Italic,
                                        color = ShahiGold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                        is ConservationState.Error -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(state.message, color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (isUrdu) "ٹھیک ہے" else "Close Report")
                }
            }
        }
    }
}

// --- DYNAMIC COMPANION DIALOG 6: SOCIAL DISCOVERY CARD ---

@Composable
fun DiscoveryCardDisplayDialog(
    siteName: String,
    era: String,
    city: String,
    userName: String,
    isUrdu: Boolean,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val discoveryState by viewModel.discoveryCardState.collectAsState()

    LaunchedEffect(siteName, era) {
        viewModel.generateDiscoveryCard(siteName, era, city, userName)
    }

    Dialog(onDismissRequest = {
        viewModel.resetDiscoveryCardState()
        onDismiss()
    }) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.82f)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.IosShare, contentDescription = null, tint = ShahiGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isUrdu) "شوسل میڈیا کارڈ" else "Heritage Discovery Card",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (val state = discoveryState) {
                        is DiscoveryCardState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(if (isUrdu) "کارڈ بنایا جا رہا ہے..." else "Layouting discover banner card...", fontSize = 12.sp, color = TextSecondary)
                            }
                        }
                        is DiscoveryCardState.Generating -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = ShahiGold)
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (isUrdu) "اے آئی کی طرف سے دیدہ زیب شیئر کارڈ اور سرخیاں لکھی جا رہی ہیں..." else "Writing beautiful social punchlines, taglines, & hashtags with AI...",
                                    fontSize = 12.sp,
                                    color = ShahiGold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 16.dp)
                                )
                            }
                        }
                        is DiscoveryCardState.Success -> {
                            val card = state.card
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .border(2.dp, ShahiGold, RoundedCornerShape(16.dp)),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Column(modifier = Modifier.fillMaxSize()) {
                                        // Header image banner representing historic architecture
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(95.dp)
                                                .background(
                                                    Brush.verticalGradient(
                                                        colors = listOf(LightEmerald.copy(alpha = 0.9f), EmeraldGreen)
                                                    )
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    Icons.Default.WorkspacePremium,
                                                    contentDescription = null,
                                                    tint = ShahiGold,
                                                    modifier = Modifier.size(32.dp)
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = if (isUrdu) "تصدیق شدہ دریافت" else "OFFICIAL DISCOVERY",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp,
                                                    color = ShahiGold,
                                                    letterSpacing = 1.sp
                                                )
                                            }
                                        }

                                        Column(
                                            modifier = Modifier.padding(14.dp).weight(1f),
                                            verticalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(card.headline, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, lineHeight = 19.sp)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(card.oneLiner, fontSize = 11.sp, color = ShahiGold, fontWeight = FontWeight.SemiBold)
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(card.discoveryCaption, fontSize = 10.sp, color = Color.White.copy(alpha = 0.9f), lineHeight = 14.sp)
                                            }

                                            Column {
                                                if (card.urduTagline.isNotBlank()) {
                                                    Text(card.urduTagline, fontSize = 12.sp, color = ShahiGold, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.End))
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                }
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.Bottom
                                                ) {
                                                    Column {
                                                        Text(siteName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                        Text("$era • $city", color = Color.White.copy(alpha = 0.7f), fontSize = 8.sp)
                                                    }
                                                    Text(
                                                        text = card.hashtags.joinToString(" "),
                                                        color = ShahiGold,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = if (isUrdu) "✓ کارڈ شیئر اور محفوظ کرنے کے لئے تیار ہے!" else "✓ Discovery card rendered! Ready to share and download.",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EmeraldGreen,
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            try {
                                                val cardBitmap = drawDiscoveryCardToBitmap(card, siteName, era, city)
                                                val success = saveBitmapToGallery(context, cardBitmap, siteName)
                                                if (success) {
                                                    Toast.makeText(context, if (isUrdu) "کارڈ گیلری میں محفوظ ہو گیا ہے!" else "Discovery Card saved to gallery successfully as PNG!", Toast.LENGTH_LONG).show()
                                                } else {
                                                    Toast.makeText(context, "Error saving picture to gallery.", Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isUrdu) "ڈاؤن لوڈ کریں" else "Download", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_SUBJECT, "KHOJ AI Heritage Discovery")
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    """
                                                    ✨ ${card.headline} ✨
                                                    
                                                    "${card.oneLiner}"
                                                    
                                                    🏛️ Site: $siteName ($city)
                                                    🗺️ Era: $era
                                                    
                                                    📜 Description:
                                                    ${card.discoveryCaption}
                                                    
                                                    🇵🇰 ${card.urduTagline}
                                                    
                                                    Explore more lost history with KHOJ App!
                                                    ${card.hashtags.joinToString(" ")}
                                                    """.trimIndent()
                                                )
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Discovery Card"))
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = ShahiGold),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isUrdu) "شیئر کریں" else "Share Card", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        is DiscoveryCardState.Error -> {
                             Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                 Text(state.message, color = Color.Red, fontSize = 12.sp, textAlign = TextAlign.Center)
                             }
                        }
                    }
                }
            }
        }
    }
}

// --- DISCOVERY CARD PNG PROGRAMMATIC EXPORT SYSTEM ---

private fun drawDiscoveryCardToBitmap(
    card: com.example.data.DiscoveryCardContent,
    siteName: String,
    era: String,
    city: String
): Bitmap {
    val width = 800
    val height = 1150
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Base palette
    val bgColors = 0xFF1B1C17.toInt()       // Dark Slate Olive background
    val borderColor = 0xFFAC7765.toInt()   // Shahi Gold
    val bannerColor = 0xFF8C8E75.toInt()    // Emerald green header accent
    val textColorLight = 0xFFFAF2E6.toInt() // Antique ivory

    // 1. Draw solid background
    val bgPaint = Paint().apply {
        color = bgColors
        style = Paint.Style.FILL
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

    // 2. Draw border
    val borderPaint = Paint().apply {
        color = borderColor
        style = Paint.Style.STROKE
        strokeWidth = 12f
    }
    canvas.drawRect(24f, 24f, width.toFloat() - 24f, height.toFloat() - 24f, borderPaint)

    // 3. Draw header banner
    val bannerPaint = Paint().apply {
        color = bannerColor
        style = Paint.Style.FILL
    }
    canvas.drawRect(24f, 24f, width.toFloat() - 24f, 200f, bannerPaint)

    // Header labels
    val appTitlePaint = Paint().apply {
        color = textColorLight
        textSize = 34f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    canvas.drawText("OFFICIAL DISCOVERY CARD", (width / 2).toFloat(), 95f, appTitlePaint)

    val subtitleLabelPaint = Paint().apply {
        color = borderColor
        textSize = 24f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    canvas.drawText("KHOJ - LOST HERITAGE COMPANION", (width / 2).toFloat(), 150f, subtitleLabelPaint)

    // Line separator
    val dividerPaint = Paint().apply {
        color = borderColor
        strokeWidth = 4f
    }
    canvas.drawLine(24f, 200f, width.toFloat() - 24f, 200f, dividerPaint)

    // Content Coordinates
    var currentY = 270f
    val margin = 55f
    val maxContentWidth = (width - 110).toFloat()

    // Headline
    val hrLinePaint = Paint().apply {
        color = textColorLight
        textSize = 38f
        isFakeBoldText = true
        isAntiAlias = true
    }
    val wrapHeadline = wrapText(card.headline, hrLinePaint, maxContentWidth)
    wrapHeadline.forEach { line ->
        canvas.drawText(line, margin, currentY, hrLinePaint)
        currentY += hrLinePaint.textSize + 12f
    }
    currentY += 15f

    // One liner
    val tagPaint = Paint().apply {
        color = borderColor
        textSize = 28f
        isFakeBoldText = true
        isAntiAlias = true
    }
    val wrapOneLiner = wrapText(card.oneLiner, tagPaint, maxContentWidth)
    wrapOneLiner.forEach { line ->
        canvas.drawText(line, margin, currentY, tagPaint)
        currentY += tagPaint.textSize + 10f
    }
    currentY += 25f

    // Caption logic
    val bodyPaint = Paint().apply {
        color = textColorLight
        textSize = 22f
        isAntiAlias = true
    }
    val wrapCaption = wrapText(card.discoveryCaption, bodyPaint, maxContentWidth)
    wrapCaption.forEach { line ->
        canvas.drawText(line, margin, currentY, bodyPaint)
        currentY += bodyPaint.textSize + 12f
    }
    currentY += 40f

    // Urdu Tagline (Right aligned, beautifully printed)
    if (card.urduTagline.isNotBlank()) {
        val urduTextPaint = Paint().apply {
            color = borderColor
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(card.urduTagline, (width - margin).toFloat(), currentY, urduTextPaint)
        currentY += urduTextPaint.textSize + 40f
    }

    // Draw Footer card box
    val footerBoxPaint = Paint().apply {
        color = 0xFF2A2B23.toInt()
        style = Paint.Style.FILL
    }
    canvas.drawRect(50f, height - 165f, width.toFloat() - 50f, height.toFloat() - 50f, footerBoxPaint)
    
    val footerBorderPaint = Paint().apply {
        color = bannerColor
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    canvas.drawRect(50f, height - 165f, width.toFloat() - 50f, height.toFloat() - 50f, footerBorderPaint)

    // Draw Site Info left
    val siteNamePaint = Paint().apply {
        color = textColorLight
        textSize = 26f
        isFakeBoldText = true
        isAntiAlias = true
    }
    canvas.drawText(siteName, 70f, (height - 110).toFloat(), siteNamePaint)

    val extraInfoPaint = Paint().apply {
        color = textColorLight
        textSize = 20f
        isAntiAlias = true
    }
    canvas.drawText("$era • $city", 70f, (height - 65).toFloat(), extraInfoPaint)

    // Draw hashtags right aligned
    val hashPaint = Paint().apply {
        color = borderColor
        textSize = 20f
        isFakeBoldText = true
        isAntiAlias = true
        textAlign = Paint.Align.RIGHT
    }
    canvas.drawText(card.hashtags.joinToString(" "), (width - 70).toFloat(), (height - 90).toFloat(), hashPaint)

    return bitmap
}

private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
    val words = text.split(" ")
    val lines = mutableListOf<String>()
    var currentLine = StringBuilder()

    for (word in words) {
        val testLine = if (currentLine.isEmpty()) word else "${currentLine} $word"
        val testWidth = paint.measureText(testLine)
        if (testWidth <= maxWidth) {
            currentLine.append(if (currentLine.isEmpty()) word else " $word")
        } else {
            lines.add(currentLine.toString())
            currentLine = StringBuilder(word)
        }
    }
    if (currentLine.isNotEmpty()) {
        lines.add(currentLine.toString())
    }
    return lines
}

private fun saveBitmapToGallery(context: Context, bitmap: Bitmap, title: String): Boolean {
    val resolver = context.contentResolver
    val imageDetails = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "${title.replace(" ", "_")}_Discovery")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Khoj_Discoveries")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }

    val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageDetails)
    if (imageUri != null) {
        try {
            resolver.openOutputStream(imageUri).use { outputStream ->
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                imageDetails.clear()
                imageDetails.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(imageUri, imageDetails, null, null)
            }
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                resolver.delete(imageUri, null, null)
            } catch (ex: java.lang.Exception) {}
        }
    }
    return false
}



